package com.logprocessor.service;

import com.logprocessor.config.FileProperties;
import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Moves processed / failed files into date-partitioned sub-directories.
 *
 * All base folder paths come from {@link FileProperties} which normalises
 * Windows backslash paths before returning them.  Date sub-directories
 * use the OS file separator automatically via {@link Path#resolve}.
 *
 * Result structure on Windows:
 *   D:\LogFiles\processed\2024\01\15\events.csv
 *   D:\LogFiles\error\2024\01\15\broken.xlsx
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileMoverService {

    /** Uses OS-safe path separator inside date segments. */
    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("yyyy" + File.separator +
                                        "MM"   + File.separator + "dd");

    private final FileProperties fileProperties;
    private final FileProcessingMetadataRepository metadataRepository;

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    @Transactional
    public void moveToProcessed(File file) {
        Path dest = resolveDestination(fileProperties.getProcessedPath(), file.getName());
        moveFile(file, dest);
        updateStatus(file.getName(), dest.toString(), FileProcessingMetadata.ProcessingStatus.MOVED);
    }

    @Transactional
    public void moveToError(File file, String errorReason) {
        Path dest = resolveDestination(fileProperties.getErrorPath(), file.getName());
        moveFile(file, dest);
        updateStatusFailed(file.getName(), dest.toString(), errorReason);
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Builds the full destination path including the date sub-directory.
     * Creates the directory hierarchy if it does not exist.
     *
     * Example (Windows):  D:\LogFiles\processed\2024\01\15\events.csv
     */
    private Path resolveDestination(Path baseFolder, String fileName) {
        String datePart = LocalDate.now().format(DATE_FORMAT);
        // Path.resolve() handles OS separators automatically
        Path dir = baseFolder.resolve(datePart);
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            log.warn("Could not create destination directory '{}': {}", dir, e.getMessage());
        }
        return deduplicateFileName(dir.resolve(fileName));
    }

    /**
     * If a file with the same name already exists at {@code target},
     * appends a millisecond timestamp before the extension.
     *
     * e.g.  events.csv  →  events_1705312800000.csv
     */
    private Path deduplicateFileName(Path target) {
        if (!Files.exists(target)) {
            return target;
        }
        String name  = target.getFileName().toString();
        int    dot   = name.lastIndexOf('.');
        String ts    = "_" + System.currentTimeMillis();
        String newName = (dot >= 0)
                ? name.substring(0, dot) + ts + name.substring(dot)
                : name + ts;
        return target.getParent().resolve(newName);
    }

    /**
     * Moves {@code source} to {@code target}.
     *
     * Attempts ATOMIC_MOVE first (same filesystem).
     * Falls back to REPLACE_EXISTING copy+delete for cross-drive moves
     * (e.g., source on D:\ processed on E:\).
     */
    private void moveFile(File source, Path target) {
        log.info("Moving '{}' → '{}'", source.getAbsolutePath(), target);
        try {
            Files.move(source.toPath(), target, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            // Cross-filesystem / cross-drive move (e.g. D:\ → E:\)
            log.debug("Atomic move not supported — falling back to copy+delete for: {}",
                    source.getName());
            try {
                Files.move(source.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                log.error("Failed to move '{}' to '{}': {}",
                        source.getName(), target, ex.getMessage(), ex);
            }
        } catch (IOException e) {
            log.error("Failed to move '{}' to '{}': {}",
                    source.getName(), target, e.getMessage(), e);
        }
    }

    private void updateStatus(String fileName, String newPath,
                              FileProcessingMetadata.ProcessingStatus status) {
        Optional<FileProcessingMetadata> meta = metadataRepository.findByFileName(fileName);
        meta.ifPresent(m -> {
            m.setProcessedPath(newPath);
            m.setStatus(status);
            metadataRepository.save(m);
        });
    }

    private void updateStatusFailed(String fileName, String newPath, String errorMsg) {
        Optional<FileProcessingMetadata> meta = metadataRepository.findByFileName(fileName);
        meta.ifPresent(m -> {
            m.setProcessedPath(newPath);
            m.setStatus(FileProcessingMetadata.ProcessingStatus.FAILED);
            m.setErrorMessage(errorMsg);
            metadataRepository.save(m);
        });
    }
}
