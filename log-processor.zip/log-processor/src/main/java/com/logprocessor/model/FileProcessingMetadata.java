package com.logprocessor.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Tracks metadata and processing status for each file.
 *
 * DDL is managed by schema.sql (spring.sql.init.mode=always).
 * Hibernate ddl-auto is set to 'none' — no auto table generation.
 */
@Entity
@Table(name = "file_processing_metadata", indexes = {
        @Index(name = "idx_file_metadata_file_name", columnList = "file_name"),
        @Index(name = "idx_file_metadata_status",    columnList = "status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileProcessingMetadata {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", nullable = false, unique = true, length = 512)
    private String fileName;

    @Column(name = "source_path", nullable = false, length = 512)
    private String sourcePath;

    @Column(name = "processed_path", length = 512)
    private String processedPath;

    @Column(name = "file_size_bytes", nullable = false)
    private Long fileSizeBytes;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private ProcessingStatus status;

    @Enumerated(EnumType.STRING)
    @Column(name = "file_type", nullable = false, length = 20)
    private LogRecord.FileType fileType;

    @Column(name = "total_records")
    private Long totalRecords;

    @Column(name = "processed_records")
    private Long processedRecords;

    @Column(name = "failed_records")
    private Long failedRecords;

    @Lob
    @Column(name = "error_message")
    private String errorMessage;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum ProcessingStatus {
        PENDING, IN_PROGRESS, COMPLETED, FAILED, MOVED
    }
}
