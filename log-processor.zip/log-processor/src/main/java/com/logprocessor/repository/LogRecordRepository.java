package com.logprocessor.repository;

import com.logprocessor.model.LogRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LogRecordRepository extends JpaRepository<LogRecord, Long> {
    long countBySourceFile(String sourceFile);
    void deleteBySourceFile(String sourceFile);
}
