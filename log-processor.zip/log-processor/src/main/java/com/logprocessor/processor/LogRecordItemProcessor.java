package com.logprocessor.processor;

import com.logprocessor.model.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

/**
 * Spring Batch ItemProcessor that validates and enriches LogRecord objects.
 * Returns null to filter out invalid records (Spring Batch skips nulls).
 */
@Component
@Slf4j
public class LogRecordItemProcessor implements ItemProcessor<LogRecord, LogRecord> {

    private static final int MAX_MESSAGE_LENGTH = 4000;
    private static final int MAX_RAW_LENGTH = 8000;

    @Override
    public LogRecord process(@NonNull LogRecord item) throws Exception {
        // Filter out completely empty records
        if (isEmptyRecord(item)) {
            log.trace("Filtering empty record from file: {}, line: {}", item.getSourceFile(), item.getLineNumber());
            return null;
        }

        // Normalize and truncate fields
        enrichRecord(item);

        return item;
    }

    private boolean isEmptyRecord(LogRecord record) {
        return StringUtils.isBlank(record.getMessage())
                && StringUtils.isBlank(record.getRawContent())
                && StringUtils.isBlank(record.getTimestamp());
    }

    private void enrichRecord(LogRecord record) {
        // Normalize log level
        if (StringUtils.isNotBlank(record.getLogLevel())) {
            record.setLogLevel(record.getLogLevel().toUpperCase().trim());
        }

        // Normalize and validate known log levels
        String level = record.getLogLevel();
        if (level != null) {
            record.setLogLevel(switch (level) {
                case "WARNING" -> "WARN";
                case "SEVERE"  -> "ERROR";
                default        -> level;
            });
        }

        // Truncate long fields to prevent DB column overflow
        if (record.getMessage() != null && record.getMessage().length() > MAX_MESSAGE_LENGTH) {
            record.setMessage(record.getMessage().substring(0, MAX_MESSAGE_LENGTH));
        }
        if (record.getRawContent() != null && record.getRawContent().length() > MAX_RAW_LENGTH) {
            record.setRawContent(record.getRawContent().substring(0, MAX_RAW_LENGTH));
        }

        // Trim string fields
        record.setTimestamp(StringUtils.trimToNull(record.getTimestamp()));
        record.setComponent(StringUtils.trimToNull(record.getComponent()));
    }
}
