package com.logprocessor.writer;

import com.logprocessor.model.LogRecord;
import com.logprocessor.repository.LogRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

/**
 * Spring Batch ItemWriter that bulk-saves LogRecord objects to the database.
 * Uses JPA batch inserts (configured via hibernate.jdbc.batch_size in application.yml).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class LogRecordItemWriter implements ItemWriter<LogRecord> {

    private final LogRecordRepository logRecordRepository;

    @Override
    public void write(Chunk<? extends LogRecord> chunk) throws Exception {
        if (chunk.isEmpty()) return;

        try {
            logRecordRepository.saveAll(chunk.getItems());
            log.debug("Wrote {} records to database", chunk.size());
        } catch (Exception e) {
            log.error("Failed to write {} records to database: {}", chunk.size(), e.getMessage(), e);
            throw e;
        }
    }
}
