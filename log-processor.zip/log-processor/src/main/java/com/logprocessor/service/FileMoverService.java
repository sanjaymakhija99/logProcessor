package com.logprocessor.service;

import com.logprocessor.config.FileProperties;
import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Moves processed files to designated folders.
 * Creates date-partitioned subdirectories to prevent folder bloat.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileMoverService {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd");

    private final FileProperties fileProperties;
    private final FileProcessingMetadataRepository metadataRepository;

    /**
     * Moves a successfully processed file to the processed folder.
     */
    @Transactional
    public void moveToProcessed(File file) {
        Path destination = resolveDestination(fileProperties.getProcessedFolder(), file.getName());
        move(file, destination);
        updateMetadataOnMove(file.getName(), destination.toString(),
                FileProcessingMetadata.ProcessingStatus.MOVED);
    }

    /**
     * Moves a failed file to the error folder.
     */
    @Transactional
    public void moveToError(File file, String errorReason) {
        Path destination = resolveDestination(fileProperties.getErrorFolder(), file.getName());
        move(file, destination);
        updateMetadataOnError(file.getName(), destination.toString(), errorReason);
    }

    private Path resolveDestination(String baseFolder, String fileName) {
        String datePath = LocalDate.now().format(DATE_FORMATTER);
        Path dir = Paths.get(baseFolder, datePath);
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            log.warn("Could not create directory: {}", dir, e);
        }
        return dir.resolve(fileName);
    }

    private void move(File source, Path destination) {
        try {
            // If a file with the same name already exists, append a timestamp
            Path target = destination;
            if (Files.exists(destination)) {
                String name = destination.getFileName().toString();
                int dot = name.lastIndexOf('.');
                String timestamp = "_" + System.currentTimeMillis();
                String newName = (dot >= 0)
                        ? name.substring(0, dot) + timestamp + name.substring(dot)
                        : name + timestamp;
                target = destination.getParent().resolve(newName);
            }

            Files.move(source.toPath(), target, StandardCopyOption.ATOMIC_MOVE);
            log.info("Moved file '{}' → '{}'", source.getName(), target);

        } catch (AtomicMoveNotSupportedException e) {
            // Fallback for cross-filesystem moves
            try {
                Files.move(source.toPath(), destination, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                log.error("Failed to move file: {}", source.getName(), ex);
            }
        } catch (IOException e) {
            log.error("Failed to move file '{}': {}", source.getName(), e.getMessage(), e);
        }
    }

    private void updateMetadataOnMove(String fileName, String newPath, FileProcessingMetadata.ProcessingStatus status) {
        Optional<FileProcessingMetadata> meta = metadataRepository.findByFileName(fileName);
        meta.ifPresent(m -> {
            m.setProcessedPath(newPath);
            m.setStatus(status);
            metadataRepository.save(m);
        });
    }

    private void updateMetadataOnError(String fileName, String newPath, String errorMsg) {
        Optional<FileProcessingMetadata> meta = metadataRepository.findByFileName(fileName);
        meta.ifPresent(m -> {
            m.setProcessedPath(newPath);
            m.setStatus(FileProcessingMetadata.ProcessingStatus.FAILED);
            m.setErrorMessage(errorMsg);
            metadataRepository.save(m);
        });
    }
}
