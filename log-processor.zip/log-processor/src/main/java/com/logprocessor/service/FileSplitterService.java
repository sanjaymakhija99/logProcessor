package com.logprocessor.service;

import com.logprocessor.config.FileProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Responsible for deciding how to split a large file into processing chunks.
 * Does NOT physically split files on disk; instead returns ChunkDescriptors
 * that tell the reader which lines to process.
 *
 * This avoids disk I/O overhead for splitting and lets Spring Batch handle
 * the parallelism at the step level.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileSplitterService {

    private final FileProperties fileProperties;

    /**
     * Returns a list of chunks for a file.
     * If the file is small, returns one chunk covering the whole file.
     * If large, returns multiple chunks based on maxLinesPerSplit.
     */
    public List<FileChunk> calculateChunks(File file, long totalRecords) {
        List<FileChunk> chunks = new ArrayList<>();

        boolean needsSplitting = file.length() > fileProperties.getSplitThresholdBytes()
                || totalRecords > fileProperties.getMaxLinesPerSplit();

        if (!needsSplitting) {
            chunks.add(new FileChunk(file, 0, (int) totalRecords, 0));
            return chunks;
        }

        int chunkSize = fileProperties.getMaxLinesPerSplit();
        int chunkIndex = 0;
        long startLine = 0;

        while (startLine < totalRecords) {
            long endLine = Math.min(startLine + chunkSize, totalRecords);
            int lines = (int) (endLine - startLine);
            chunks.add(new FileChunk(file, startLine, lines, chunkIndex));
            log.debug("Created chunk {}: file={}, startLine={}, lines={}",
                    chunkIndex, file.getName(), startLine, lines);
            startLine += chunkSize;
            chunkIndex++;
        }

        log.info("Split file '{}' ({} bytes, {} records) into {} chunks",
                file.getName(), file.length(), totalRecords, chunks.size());
        return chunks;
    }

    /**
     * Represents a logical chunk of a file to be processed.
     * Immutable value object.
     */
    public record FileChunk(File file, long startLine, int maxLines, int chunkIndex) {
        public String chunkId() {
            return file.getName() + "_chunk_" + chunkIndex;
        }
    }
}
