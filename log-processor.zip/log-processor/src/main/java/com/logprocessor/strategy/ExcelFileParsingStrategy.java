package com.logprocessor.strategy;

import com.logprocessor.model.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.model.SharedStrings;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.springframework.stereotype.Component;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Parses Excel files (.xlsx, .xls).
 * Uses SAX streaming parser for large files to avoid OOM errors.
 * Falls back to DOM-style parsing for smaller files.
 */
@Component
@Slf4j
public class ExcelFileParsingStrategy implements FileParsingStrategy {

    private static final long STREAMING_THRESHOLD_BYTES = 10 * 1024 * 1024; // 10 MB

    @Override
    public boolean supports(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        return "xlsx".equals(ext) || "xls".equals(ext);
    }

    @Override
    public List<LogRecord> parse(File file, long startLine, int maxLines) {
        if (file.length() > STREAMING_THRESHOLD_BYTES) {
            return parseStreaming(file, startLine, maxLines);
        }
        return parseDom(file, startLine, maxLines);
    }

    @Override
    public long countRecords(File file) {
        long count = 0;
        try (Workbook workbook = WorkbookFactory.create(file)) {
            Sheet sheet = workbook.getSheetAt(0);
            // getLastRowNum() is 0-based and inclusive, subtract 1 for header row
            count = Math.max(0, sheet.getLastRowNum());
        } catch (Exception e) {
            log.error("Error counting rows in Excel file: {}", file.getName(), e);
        }
        return count;
    }

    @Override
    public LogRecord.FileType getFileType() {
        return LogRecord.FileType.EXCEL;
    }

    private List<LogRecord> parseDom(File file, long startLine, int maxLines) {
        List<LogRecord> records = new ArrayList<>();
        try (Workbook workbook = WorkbookFactory.create(file)) {
            Sheet sheet = workbook.getSheetAt(0);
            Row headerRow = sheet.getRow(0);
            String[] headers = extractHeaders(headerRow);

            long rowIndex = 0;
            long linesRead = 0;

            Iterator<Row> rowIterator = sheet.iterator();
            if (rowIterator.hasNext()) rowIterator.next(); // skip header

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                if (rowIndex < startLine) { rowIndex++; continue; }
                if (maxLines > 0 && linesRead >= maxLines) break;

                LogRecord record = parseRow(row, headers, file.getName(), rowIndex + 2);
                if (record != null) {
                    records.add(record);
                    linesRead++;
                }
                rowIndex++;
            }
        } catch (Exception e) {
            log.error("Error parsing Excel file: {}", file.getName(), e);
        }
        return records;
    }

    /**
     * SAX-based streaming parser for very large Excel files.
     * Avoids loading the entire workbook into memory.
     */
    private List<LogRecord> parseStreaming(File file, long startLine, int maxLines) {
        List<LogRecord> records = new ArrayList<>();
        try (OPCPackage pkg = OPCPackage.open(file)) {
            XSSFReader xssfReader = new XSSFReader(pkg);
            StylesTable styles = xssfReader.getStylesTable();
            SharedStrings sharedStrings = xssfReader.getSharedStringsTable();

            StreamingSheetHandler sheetHandler = new StreamingSheetHandler(
                    file.getName(), startLine, maxLines, records);

            // XSSFSheetXMLHandler extends DefaultHandler — assign to DefaultHandler, not ContentHandler
            XSSFSheetXMLHandler handler = new XSSFSheetXMLHandler(
                    styles, sharedStrings, sheetHandler, false);

            SAXParserFactory factory = SAXParserFactory.newInstance();
            factory.setNamespaceAware(true);
            SAXParser saxParser = factory.newSAXParser();
            XMLReader xmlReader = saxParser.getXMLReader();
            // XSSFSheetXMLHandler implements ContentHandler via DefaultHandler
            xmlReader.setContentHandler(handler);

            XSSFReader.SheetIterator sheetsData = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
            if (sheetsData.hasNext()) {
                try (InputStream sheetStream = sheetsData.next()) {
                    xmlReader.parse(new InputSource(sheetStream));
                }
            }
        } catch (Exception e) {
            log.error("Error streaming Excel file: {}", file.getName(), e);
        }
        return records;
    }

    private String[] extractHeaders(Row headerRow) {
        if (headerRow == null) return new String[0];
        String[] headers = new String[headerRow.getLastCellNum()];
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.getCell(i);
            headers[i] = (cell != null) ? cell.getStringCellValue() : "";
        }
        return headers;
    }

    private LogRecord parseRow(Row row, String[] headers, String fileName, long lineNumber) {
        if (row == null) return null;
        DataFormatter formatter = new DataFormatter();

        String[] values = new String[Math.max(headers.length, row.getLastCellNum())];
        for (int i = 0; i < values.length; i++) {
            Cell cell = row.getCell(i);
            values[i] = (cell != null) ? formatter.formatCellValue(cell) : "";
        }

        String timestamp = getByHeader(values, headers, "timestamp", 0);
        String logLevel  = getByHeader(values, headers, "level", 1);
        String component = getByHeader(values, headers, "component", 2);
        String message   = getByHeader(values, headers, "message", 3);
        String raw       = String.join(",", values);

        return LogRecord.builder()
                .sourceFile(fileName)
                .lineNumber(lineNumber)
                .timestamp(timestamp)
                .logLevel(logLevel)
                .component(component)
                .message(message)
                .rawContent(raw)
                .fileType(LogRecord.FileType.EXCEL)
                .build();
    }

    private String getByHeader(String[] values, String[] headers, String name, int fallback) {
        for (int i = 0; i < headers.length; i++) {
            if (headers[i].equalsIgnoreCase(name) && i < values.length) return values[i];
        }
        return (fallback < values.length) ? values[fallback] : "";
    }

    // -----------------------------------------------------------------------
    // Inner class: SAX streaming sheet handler
    // -----------------------------------------------------------------------
    private static class StreamingSheetHandler implements SheetContentsHandler {

        private final String fileName;
        private final long startLine;
        private final int maxLines;
        private final List<LogRecord> records;

        private long currentRow = -1; // -1 = before any row
        private String[] headers = null;
        private String[] currentRowValues = new String[20];
        private long linesRead = 0;

        StreamingSheetHandler(String fileName, long startLine, int maxLines, List<LogRecord> records) {
            this.fileName = fileName;
            this.startLine = startLine;
            this.maxLines = maxLines;
            this.records = records;
        }

        @Override
        public void startRow(int rowNum) {
            currentRow = rowNum;
            currentRowValues = new String[20];
        }

        @Override
        public void endRow(int rowNum) {
            if (currentRow == 0) {
                // Header row
                headers = currentRowValues.clone();
                return;
            }
            long dataRow = currentRow - 1; // 0-based data row index
            if (dataRow < startLine) return;
            if (maxLines > 0 && linesRead >= maxLines) return;

            String[] h = (headers != null) ? headers : new String[0];
            String timestamp = getVal(h, "timestamp", 0);
            String level     = getVal(h, "level", 1);
            String component = getVal(h, "component", 2);
            String message   = getVal(h, "message", 3);

            records.add(LogRecord.builder()
                    .sourceFile(fileName)
                    .lineNumber(currentRow + 1L)
                    .timestamp(timestamp)
                    .logLevel(level)
                    .component(component)
                    .message(message)
                    .rawContent(String.join(",", currentRowValues))
                    .fileType(LogRecord.FileType.EXCEL)
                    .build());
            linesRead++;
        }

        @Override
        public void cell(String cellReference, String formattedValue, XSSFComment comment) {
            if (cellReference == null) return;
            int col = columnIndex(cellReference);
            if (col >= currentRowValues.length) {
                String[] expanded = new String[col + 10];
                System.arraycopy(currentRowValues, 0, expanded, 0, currentRowValues.length);
                currentRowValues = expanded;
            }
            currentRowValues[col] = (formattedValue != null) ? formattedValue : "";
        }

        private String getVal(String[] headers, String name, int fallback) {
            for (int i = 0; i < headers.length; i++) {
                if (name.equalsIgnoreCase(headers[i]) && i < currentRowValues.length)
                    return currentRowValues[i] != null ? currentRowValues[i] : "";
            }
            return (fallback < currentRowValues.length && currentRowValues[fallback] != null)
                    ? currentRowValues[fallback] : "";
        }

        private int columnIndex(String cellRef) {
            int col = 0;
            for (char c : cellRef.toCharArray()) {
                if (!Character.isLetter(c)) break;
                col = col * 26 + (Character.toUpperCase(c) - 'A' + 1);
            }
            return col - 1;
        }
    }
}
