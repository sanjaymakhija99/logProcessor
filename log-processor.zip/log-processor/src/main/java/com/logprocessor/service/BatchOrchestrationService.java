package com.logprocessor.service;

import com.logprocessor.config.BatchJobConfig;
import com.logprocessor.config.BatchProperties;
import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import com.logprocessor.service.FileSplitterService.FileChunk;
import com.logprocessor.strategy.FileParsingStrategy;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Orchestrates processing of multiple files concurrently.
 *
 * For each file:
 *   1. Resolves the correct FileParsingStrategy
 *   2. Counts total records and calculates FileChunks
 *   3. Submits each chunk as a CompletableFuture (runs a dedicated Batch Step)
 *   4. Waits for all chunks to finish before releasing the semaphore permit
 *
 * A Semaphore caps how many files are processed simultaneously (maxConcurrentJobs).
 * Java 21 Virtual Threads are used for the per-file outer concurrency layer.
 */
@Service
@Slf4j
public class BatchOrchestrationService {

    private final JobLauncher jobLauncher;
    private final Job fileProcessingJob;
    private final BatchJobConfig batchJobConfig;
    private final FileSplitterService fileSplitterService;
    private final FileParsingStrategyResolver strategyResolver;
    private final FileProcessingMetadataRepository metadataRepository;
    private final BatchProperties batchProperties;
    private final TaskExecutor taskExecutor;

    public BatchOrchestrationService(
            JobLauncher jobLauncher,
            @Qualifier("fileProcessingJob") Job fileProcessingJob,
            BatchJobConfig batchJobConfig,
            FileSplitterService fileSplitterService,
            FileParsingStrategyResolver strategyResolver,
            FileProcessingMetadataRepository metadataRepository,
            BatchProperties batchProperties,
            @Qualifier("batchTaskExecutor") TaskExecutor taskExecutor) {

        this.jobLauncher         = jobLauncher;
        this.fileProcessingJob   = fileProcessingJob;
        this.batchJobConfig      = batchJobConfig;
        this.fileSplitterService = fileSplitterService;
        this.strategyResolver    = strategyResolver;
        this.metadataRepository  = metadataRepository;
        this.batchProperties     = batchProperties;
        this.taskExecutor        = taskExecutor;
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Processes all supplied files concurrently, honouring the maxConcurrentJobs cap.
     */
    public void processFiles(List<File> files) {
        if (files.isEmpty()) {
            log.info("No files to process.");
            return;
        }

        Semaphore semaphore = new Semaphore(batchProperties.getMaxConcurrentJobs());
        List<Future<?>> futures = new ArrayList<>();

        // Virtual threads are cheap for I/O-bound per-file work (Java 21)
        ExecutorService virtualExecutor = Executors.newVirtualThreadPerTaskExecutor();

        for (File file : files) {
            try {
                semaphore.acquire();
                Future<?> future = virtualExecutor.submit(() -> {
                    try {
                        processFile(file);
                    } finally {
                        semaphore.release();
                    }
                });
                futures.add(future);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.error("Interrupted while acquiring semaphore for file: {}", file.getName());
            }
        }

        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (ExecutionException e) {
                log.error("File processing task failed: {}", e.getCause().getMessage(), e);
            }
        }

        virtualExecutor.shutdown();
        log.info("Finished processing {} file(s).", files.size());
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    private void processFile(File file) {
        log.info("Starting processing: {}", file.getName());
        try {
            FileParsingStrategy strategy = strategyResolver.resolve(file);
            long totalRecords = strategy.countRecords(file);
            List<FileChunk> chunks = fileSplitterService.calculateChunks(file, totalRecords);

            updateMetadataInProgress(file.getName(), totalRecords);

            AtomicInteger processedCount = new AtomicInteger(0);
            List<CompletableFuture<Void>> chunkFutures = new ArrayList<>();

            for (FileChunk chunk : chunks) {
                CompletableFuture<Void> cf = CompletableFuture.runAsync(() -> {
                    try {
                        launchChunkJob(chunk, file);
                        processedCount.addAndGet(chunk.maxLines());
                    } catch (Exception e) {
                        log.error("Chunk failed: {} — {}", chunk.chunkId(), e.getMessage(), e);
                    }
                }, taskExecutor);
                chunkFutures.add(cf);
            }

            CompletableFuture.allOf(chunkFutures.toArray(new CompletableFuture[0])).join();

            updateMetadataProcessedCount(file.getName(), processedCount.get());
            log.info("Completed: {} ({} records)", file.getName(), totalRecords);

        } catch (Exception e) {
            log.error("Failed to process file: {}", file.getName(), e);
            updateMetadataFailed(file.getName(), e.getMessage());
        }
    }

    /**
     * Builds a dedicated Step for the chunk and runs it as a new Job execution.
     * Each chunk gets its own unique JobParameters so Spring Batch treats them
     * as independent executions with separate tracking records.
     */
    private void launchChunkJob(FileChunk chunk, File file) throws Exception {
        Step chunkStep = batchJobConfig.createChunkStep(
                "step_" + chunk.chunkId(), chunk, taskExecutor);

        JobParameters params = new JobParametersBuilder()
                .addString("fileName",     file.getName())
                .addString("filePath",     file.getAbsolutePath())
                .addLong("chunkIndex",     (long) chunk.chunkIndex())
                .addLong("startLine",      chunk.startLine())
                .addString("runTimestamp", LocalDateTime.now().toString())
                .toJobParameters();

        log.debug("Launching batch job for chunk: {}", chunk.chunkId());
        jobLauncher.run(fileProcessingJob, params);
    }

    // -----------------------------------------------------------------------
    // Metadata helpers
    // -----------------------------------------------------------------------

    private void updateMetadataInProgress(String fileName, long totalRecords) {
        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setTotalRecords(totalRecords);
            meta.setStatus(FileProcessingMetadata.ProcessingStatus.IN_PROGRESS);
            metadataRepository.save(meta);
        });
    }

    private void updateMetadataProcessedCount(String fileName, long count) {
        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setProcessedRecords(count);
            metadataRepository.save(meta);
        });
    }

    private void updateMetadataFailed(String fileName, String errorMsg) {
        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setStatus(FileProcessingMetadata.ProcessingStatus.FAILED);
            meta.setErrorMessage(errorMsg);
            metadataRepository.save(meta);
        });
    }
}
