package com.logprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class LogFileProcessorApplication {

    public static void main(String[] args) {
        SpringApplication.run(LogFileProcessorApplication.class, args);
    }
}
