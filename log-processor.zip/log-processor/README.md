# Log File Processor — Spring Boot + Spring Batch

A production-grade Spring Boot 3.x application using **Java 21** and **Spring Batch** to process large log files (CSV, Excel, TXT) concurrently, persist records to PostgreSQL, and archive processed files.

---

## Architecture Overview

```
source-folder/
  ├── app.log (TXT, 10 GB)
  ├── events.csv (CSV, 500 MB)
  └── report.xlsx (Excel, 30 MB)
         │
         ▼
 ┌─────────────────────────────────────────────┐
 │        FileProcessingScheduler              │ ← polls every 60s
 │             (scheduled)                     │
 └──────────────┬──────────────────────────────┘
                │
 ┌──────────────▼──────────────────────────────┐
 │         FileScannerService                  │ ← discovers new files
 └──────────────┬──────────────────────────────┘
                │
 ┌──────────────▼──────────────────────────────┐
 │     BatchOrchestrationService               │
 │  ┌─────────┐  ┌─────────┐  ┌─────────┐     │
 │  │ Chunk 0 │  │ Chunk 1 │  │ Chunk N │     │ ← parallel virtual threads
 │  └────┬────┘  └────┬────┘  └────┬────┘     │
 └───────┼────────────┼────────────┼───────────┘
         │            │            │
 ┌───────▼────────────▼────────────▼───────────┐
 │   Spring Batch Step (per chunk)             │
 │  Reader → Processor → Writer                │
 │  (LogFileItemReader) → (LogRecordProcessor) │
 │       → (LogRecordItemWriter → PostgreSQL)  │
 └─────────────────────────────────────────────┘
                       │
 ┌─────────────────────▼───────────────────────┐
 │         FileMoverService                    │
 │   processed/YYYY/MM/DD/  or  error/…        │
 └─────────────────────────────────────────────┘
```

---

## Design Patterns & Principles

| Pattern / Principle | Where Applied |
|---|---|
| **Strategy Pattern** | `FileParsingStrategy` + `CsvFileParsingStrategy`, `TxtFileParsingStrategy`, `ExcelFileParsingStrategy` |
| **Factory / Resolver** | `FileParsingStrategyResolver` — picks the right strategy per file extension |
| **Single Responsibility** | Each class has one clear job (scan, split, read, process, write, move) |
| **Open/Closed** | Adding a new file format = new `FileParsingStrategy` bean, zero changes elsewhere |
| **Dependency Inversion** | All services depend on abstractions/interfaces |
| **Virtual Threads (Java 21)** | `Executors.newVirtualThreadPerTaskExecutor()` for I/O-bound file operations |
| **Builder Pattern** | Lombok `@Builder` on all entities |
| **Idempotency** | `FileProcessingMetadata` tracks status; already-processed files are skipped on restart |
| **Fault Tolerance** | Spring Batch `skipLimit`, `retryLimit`, `SkipListener` |

---

## Tech Stack

- **Java 21** (Virtual Threads for I/O concurrency)
- **Spring Boot 3.2**
- **Spring Batch 5**
- **Spring Data JPA + Hibernate** (batch inserts, sequence allocation)
- **Apache POI 5** (Excel — DOM + SAX streaming for large files)
- **OpenCSV** (CSV)
- **PostgreSQL** (production) / **H2** (local dev profile)
- **Lombok** (boilerplate reduction)

---

## Project Structure

```
src/main/java/com/logprocessor/
├── LogFileProcessorApplication.java
├── config/
│   ├── BatchJobConfig.java          # Spring Batch Job/Step definitions
│   ├── BatchProperties.java         # Typed config: thread pool, max jobs
│   ├── FileProperties.java          # Typed config: folders, thresholds
│   └── ThreadPoolConfig.java        # TaskExecutor beans
├── model/
│   ├── LogRecord.java               # JPA entity: one parsed log line
│   └── FileProcessingMetadata.java  # JPA entity: file processing state
├── repository/
│   ├── LogRecordRepository.java
│   └── FileProcessingMetadataRepository.java
├── strategy/
│   ├── FileParsingStrategy.java     # Strategy interface
│   ├── CsvFileParsingStrategy.java
│   ├── TxtFileParsingStrategy.java
│   ├── ExcelFileParsingStrategy.java
│   └── FileParsingStrategyResolver.java
├── reader/
│   └── LogFileItemReader.java       # Spring Batch ItemReader
├── processor/
│   └── LogRecordItemProcessor.java  # Spring Batch ItemProcessor
├── writer/
│   └── LogRecordItemWriter.java     # Spring Batch ItemWriter
├── batch/
│   ├── FileProcessingJobListener.java
│   └── LogRecordSkipListener.java
└── service/
    ├── FileScannerService.java      # Scans source folder
    ├── FileSplitterService.java     # Calculates file chunks
    ├── FileMoverService.java        # Moves to processed/error
    ├── BatchOrchestrationService.java  # Launches jobs per file
    └── FileProcessingScheduler.java # @Scheduled trigger
```

---

## Quick Start

### Prerequisites
- Java 21+
- Maven 3.8+
- PostgreSQL 14+ (or use H2 with `local` profile)

### Run with H2 (no database setup needed)
```bash
mvn spring-boot:run -Dspring.profiles.active=local \
  -Dapp.file.source-folder=/tmp/logs/source \
  -Dapp.file.processed-folder=/tmp/logs/processed \
  -Dapp.file.error-folder=/tmp/logs/error
```

### Run with PostgreSQL
```bash
# Set up database
psql -c "CREATE DATABASE logdb;"

# Run
DB_USERNAME=postgres DB_PASSWORD=secret \
SOURCE_FOLDER=/data/logs/source \
PROCESSED_FOLDER=/data/logs/processed \
ERROR_FOLDER=/data/logs/error \
mvn spring-boot:run
```

### Drop test files and watch them process
```bash
cp large_file.csv /tmp/logs/source/
# The scheduler picks it up within 60 seconds
```

---

## Configuration Reference

| Property | Default | Description |
|---|---|---|
| `app.file.source-folder` | `/data/logs/source` | Where to scan for files |
| `app.file.processed-folder` | `/data/logs/processed` | Destination for success |
| `app.file.error-folder` | `/data/logs/error` | Destination for failures |
| `app.file.chunk-size` | `1000` | Spring Batch chunk size (rows per transaction) |
| `app.file.split-threshold-bytes` | `104857600` (100 MB) | Files larger than this get split |
| `app.file.max-lines-per-split` | `50000` | Lines per chunk for large files |
| `app.batch.thread-pool-size` | `4` | Worker threads for batch steps |
| `app.batch.max-concurrent-jobs` | `3` | Max files processed simultaneously |
| `app.scheduler.fixed-delay-ms` | `60000` | Polling interval (ms) |

---

## Expected CSV/Excel Column Format

| Column | Description |
|---|---|
| `timestamp` | Log event timestamp |
| `level` | Log level (INFO, WARN, ERROR, etc.) |
| `component` | Class/service name |
| `message` | Log message |

Columns are matched by name (case-insensitive). Unknown column layouts fall back to positional (col 0=timestamp, 1=level, 2=component, 3=message).

TXT files are parsed with the pattern:
```
2024-01-15T10:30:00 ERROR [MyClass] - Something failed
```

---

## Running Tests
```bash
mvn test
```
