package com.logprocessor.batch;

import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import com.logprocessor.service.FileMoverService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import java.io.File;
import java.time.Duration;

/**
 * Listens to Spring Batch job lifecycle events.
 *
 * beforeJob — marks the file metadata as IN_PROGRESS.
 * afterJob  — on success: marks COMPLETED and moves file to processed folder.
 *           — on failure: marks FAILED, records error, moves file to error folder.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class FileProcessingJobListener implements JobExecutionListener {

    private final FileMoverService fileMoverService;
    private final FileProcessingMetadataRepository metadataRepository;

    @Override
    public void beforeJob(@NonNull JobExecution jobExecution) {
        String fileName = jobExecution.getJobParameters().getString("fileName");
        log.info("Job starting — file: '{}' | jobId: {}", fileName, jobExecution.getJobId());

        if (fileName != null) {
            metadataRepository.findByFileName(fileName).ifPresent(meta -> {
                meta.setStatus(FileProcessingMetadata.ProcessingStatus.IN_PROGRESS);
                metadataRepository.save(meta);
            });
        }
    }

    @Override
    public void afterJob(@NonNull JobExecution jobExecution) {
        String fileName = jobExecution.getJobParameters().getString("fileName");
        String filePath = jobExecution.getJobParameters().getString("filePath");

        if (fileName == null || filePath == null) {
            log.warn("afterJob called with missing parameters — skipping file operations");
            return;
        }

        File file = new File(filePath);

        if (jobExecution.getStatus().isUnsuccessful()) {
            String error = jobExecution.getAllFailureExceptions().stream()
                    .map(Throwable::getMessage)
                    .reduce((a, b) -> a + "; " + b)
                    .orElse("Unknown error");

            log.error("Job FAILED — file: '{}' | status: {} | error: {}",
                    fileName, jobExecution.getStatus(), error);

            metadataRepository.findByFileName(fileName).ifPresent(meta -> {
                meta.setStatus(FileProcessingMetadata.ProcessingStatus.FAILED);
                meta.setErrorMessage(error);
                metadataRepository.save(meta);
            });

            if (file.exists()) {
                fileMoverService.moveToError(file, error);
            }

        } else {
            long durationMs = (jobExecution.getStartTime() != null && jobExecution.getEndTime() != null)
                    ? Duration.between(jobExecution.getStartTime(), jobExecution.getEndTime()).toMillis()
                    : -1L;

            log.info("Job COMPLETED — file: '{}' | duration: {}ms", fileName, durationMs);

            metadataRepository.findByFileName(fileName).ifPresent(meta -> {
                meta.setStatus(FileProcessingMetadata.ProcessingStatus.COMPLETED);
                metadataRepository.save(meta);
            });

            if (file.exists()) {
                fileMoverService.moveToProcessed(file);
            }
        }
    }
}
