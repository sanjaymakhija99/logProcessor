package com.logprocessor.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

/**
 * Typed configuration properties for file processing.
 * Follows the principle of externalized configuration.
 */
@Component
@ConfigurationProperties(prefix = "app.file")
@Validated
@Getter
@Setter
public class FileProperties {

    @NotBlank
    private String sourceFolder;

    @NotBlank
    private String processedFolder;

    @NotBlank
    private String errorFolder;

    @Min(1)
    private int chunkSize = 1000;

    private long splitThresholdBytes = 100 * 1024 * 1024; // 100 MB

    @Min(1000)
    private int maxLinesPerSplit = 50000;

    @NotEmpty
    private List<String> supportedExtensions;
}
