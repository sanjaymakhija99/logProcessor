package com.logprocessor;

import com.logprocessor.config.FileProperties;
import com.logprocessor.service.FileSplitterService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class FileSplitterServiceTest {

    private FileSplitterService splitterService;
    private FileProperties fileProperties;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        fileProperties = new FileProperties();
        fileProperties.setSplitThresholdBytes(1024); // 1 KB threshold for testing
        fileProperties.setMaxLinesPerSplit(100);
        splitterService = new FileSplitterService(fileProperties);
    }

    @Test
    void shouldReturnSingleChunkForSmallFile() throws Exception {
        File small = tempDir.resolve("small.csv").toFile();
        try (PrintWriter writer = new PrintWriter(small)) {
            writer.println("header");
            for (int i = 0; i < 50; i++) writer.println("line " + i);
        }

        List<FileSplitterService.FileChunk> chunks = splitterService.calculateChunks(small, 50);
        assertThat(chunks).hasSize(1);
        assertThat(chunks.get(0).startLine()).isEqualTo(0);
    }

    @Test
    void shouldSplitLargeFileIntoMultipleChunks() throws Exception {
        File large = tempDir.resolve("large.csv").toFile();
        // Create a file larger than threshold
        try (PrintWriter writer = new PrintWriter(large)) {
            for (int i = 0; i < 5000; i++) writer.println("This is a line with some content to make it large: " + i);
        }

        List<FileSplitterService.FileChunk> chunks = splitterService.calculateChunks(large, 5000);
        assertThat(chunks.size()).isGreaterThan(1);

        // Verify chunks cover all records
        long totalLines = chunks.stream().mapToLong(FileSplitterService.FileChunk::maxLines).sum();
        assertThat(totalLines).isEqualTo(5000);
    }

    @Test
    void shouldGenerateUniqueChunkIds() throws Exception {
        File file = tempDir.resolve("test.csv").toFile();
        file.createNewFile();

        List<FileSplitterService.FileChunk> chunks = splitterService.calculateChunks(file, 300);
        long distinctIds = chunks.stream().map(FileSplitterService.FileChunk::chunkId).distinct().count();
        assertThat(distinctIds).isEqualTo(chunks.size());
    }
}
