package com.logprocessor.repository;

import com.logprocessor.model.FileProcessingMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FileProcessingMetadataRepository extends JpaRepository<FileProcessingMetadata, Long> {
    Optional<FileProcessingMetadata> findByFileName(String fileName);
    List<FileProcessingMetadata> findByStatus(FileProcessingMetadata.ProcessingStatus status);
    boolean existsByFileNameAndStatus(String fileName, FileProcessingMetadata.ProcessingStatus status);
}
