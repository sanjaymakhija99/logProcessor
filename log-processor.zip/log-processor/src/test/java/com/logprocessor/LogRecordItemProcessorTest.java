package com.logprocessor;

import com.logprocessor.model.LogRecord;
import com.logprocessor.processor.LogRecordItemProcessor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class LogRecordItemProcessorTest {

    private LogRecordItemProcessor processor;

    @BeforeEach
    void setUp() {
        processor = new LogRecordItemProcessor();
    }

    @Test
    void shouldNormalizeLogLevel() throws Exception {
        LogRecord record = LogRecord.builder()
                .sourceFile("test.csv")
                .lineNumber(1L)
                .logLevel("warning")
                .message("test message")
                .rawContent("raw")
                .fileType(LogRecord.FileType.CSV)
                .build();

        LogRecord result = processor.process(record);

        assertThat(result).isNotNull();
        assertThat(result.getLogLevel()).isEqualTo("WARN");
    }

    @Test
    void shouldNormalizeSevereToError() throws Exception {
        LogRecord record = LogRecord.builder()
                .sourceFile("test.txt")
                .lineNumber(1L)
                .logLevel("SEVERE")
                .message("Critical error")
                .rawContent("raw")
                .fileType(LogRecord.FileType.TXT)
                .build();

        LogRecord result = processor.process(record);
        assertThat(result.getLogLevel()).isEqualTo("ERROR");
    }

    @Test
    void shouldFilterEmptyRecords() throws Exception {
        LogRecord record = LogRecord.builder()
                .sourceFile("test.csv")
                .lineNumber(5L)
                .fileType(LogRecord.FileType.CSV)
                .build();

        LogRecord result = processor.process(record);
        assertThat(result).isNull();
    }

    @Test
    void shouldTruncateLongMessages() throws Exception {
        String longMessage = "x".repeat(5000);
        LogRecord record = LogRecord.builder()
                .sourceFile("test.csv")
                .lineNumber(1L)
                .message(longMessage)
                .rawContent("raw")
                .fileType(LogRecord.FileType.CSV)
                .build();

        LogRecord result = processor.process(record);
        assertThat(result).isNotNull();
        assertThat(result.getMessage().length()).isLessThanOrEqualTo(4000);
    }
}
