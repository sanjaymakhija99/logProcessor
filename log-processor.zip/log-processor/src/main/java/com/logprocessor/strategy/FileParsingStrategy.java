package com.logprocessor.strategy;

import com.logprocessor.model.LogRecord;

import java.io.File;
import java.util.List;

/**
 * Strategy Pattern: defines the contract for parsing different file formats.
 * Each file type (CSV, Excel, TXT) has its own implementation.
 */
public interface FileParsingStrategy {

    /**
     * Returns true if this strategy can handle the given file.
     */
    boolean supports(File file);

    /**
     * Parses a file (or chunk) and returns a list of LogRecord objects.
     *
     * @param file      the file to parse
     * @param startLine 0-based line to start from (for chunked reading)
     * @param maxLines  max number of lines to read (-1 for all)
     * @return list of parsed records
     */
    List<LogRecord> parse(File file, long startLine, int maxLines);

    /**
     * Returns the total number of records/rows in the file.
     */
    long countRecords(File file);

    /**
     * Returns the FileType this strategy handles.
     */
    LogRecord.FileType getFileType();
}
