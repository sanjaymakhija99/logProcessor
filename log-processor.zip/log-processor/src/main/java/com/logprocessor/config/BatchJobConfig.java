package com.logprocessor.config;

import com.logprocessor.batch.FileProcessingJobListener;
import com.logprocessor.batch.LogRecordSkipListener;
import com.logprocessor.model.LogRecord;
import com.logprocessor.processor.LogRecordItemProcessor;
import com.logprocessor.reader.LogFileItemReader;
import com.logprocessor.service.FileSplitterService;
import com.logprocessor.service.FileSplitterService.FileChunk;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import com.logprocessor.writer.LogRecordItemWriter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import java.io.File;
import java.util.List;

/**
 * Configures the Spring Batch job and steps.
 *
 * Job flow:
 *   1. Scan step   - discovers files in source folder
 *   2. Process step - parallel chunk processing per file chunk
 *   3. Move step    - handled by JobExecutionListener after job ends
 *
 * For large files, multiple Steps are created dynamically (one per chunk)
 * and run in parallel using a TaskExecutor.
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class BatchJobConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final FileProperties fileProperties;
    private final FileProcessingJobListener jobListener;
    private final LogRecordSkipListener skipListener;
    private final LogRecordItemProcessor itemProcessor;
    private final LogRecordItemWriter itemWriter;
    private final FileParsingStrategyResolver strategyResolver;
    private final FileSplitterService fileSplitterService;

    @Bean("fileProcessingJob")
    public Job fileProcessingJob(@Qualifier("batchTaskExecutor") TaskExecutor taskExecutor) {
        return new JobBuilder("fileProcessingJob", jobRepository)
                .listener(jobListener)
                .start(createScanStep())
                .on("COMPLETED").to(createDynamicProcessingFlow(taskExecutor))
                .end()
                .build();
    }

    /**
     * Step 1: Validation/scan step - light tasklet that logs what will be processed.
     */
    private Step createScanStep() {
        Tasklet scanTasklet = (contribution, chunkContext) -> {
            String fileName = chunkContext.getStepContext()
                    .getJobParameters().get("fileName").toString();
            log.info("Scan step: preparing to process file '{}'", fileName);
            return RepeatStatus.FINISHED;
        };

        return new StepBuilder("scanStep", jobRepository)
                .tasklet(scanTasklet, transactionManager)
                .build();
    }

    /**
     * Creates a flow with parallel chunk-processing steps.
     * Each chunk of the file gets its own Step, run concurrently.
     */
    private org.springframework.batch.core.job.flow.Flow createDynamicProcessingFlow(TaskExecutor taskExecutor) {
        // This flow is parameterized at runtime; the actual chunking happens
        // inside the orchestration service which launches individual jobs per file.
        // Here we define the template step used for each chunk.
        return new org.springframework.batch.core.job.flow.builder.FlowBuilder<
                org.springframework.batch.core.job.flow.SimpleFlow>("processingFlow")
                .start(createChunkStep("defaultChunkStep", null, taskExecutor))
                .build();
    }

    /**
     * Creates a chunk-oriented Step for a single FileChunk.
     * Each Step reads from that chunk, processes, and writes to DB.
     */
    public Step createChunkStep(String stepName, FileChunk chunk,
                                @Qualifier("batchTaskExecutor") TaskExecutor taskExecutor) {
        return new StepBuilder(stepName, jobRepository)
                .<LogRecord, LogRecord>chunk(fileProperties.getChunkSize(), transactionManager)
                .reader(chunk != null ? new LogFileItemReader(chunk, strategyResolver) : emptyReader())
                .processor(itemProcessor)
                .writer(itemWriter)
                .faultTolerant()
                    .skipLimit(100)
                    .skip(Exception.class)
                    .retryLimit(3)
                    .retry(Exception.class)
                    .listener(skipListener)
                .taskExecutor(taskExecutor)
                .throttleLimit(fileProperties.getChunkSize())
                .build();
    }

    private org.springframework.batch.item.ItemReader<LogRecord> emptyReader() {
        return () -> null;
    }
}
