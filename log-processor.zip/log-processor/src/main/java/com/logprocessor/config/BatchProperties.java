package com.logprocessor.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app.batch")
@Getter
@Setter
public class BatchProperties {
    private int threadPoolSize = 4;
    private int maxConcurrentJobs = 3;
}
