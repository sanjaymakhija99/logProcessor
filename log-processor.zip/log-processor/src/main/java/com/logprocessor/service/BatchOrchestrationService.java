package com.logprocessor.service;

import com.logprocessor.config.BatchJobConfig;
import com.logprocessor.config.BatchProperties;
import com.logprocessor.config.FileProperties;
import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import com.logprocessor.service.FileSplitterService.FileChunk;
import com.logprocessor.strategy.FileParsingStrategy;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Orchestrates the processing of multiple files.
 * For each file:
 *   1. Calculates chunks
 *   2. Launches a Spring Batch job per file
 *   3. Within each job, runs chunks concurrently via parallel Steps
 *
 * Limits max concurrent jobs via a semaphore to avoid resource exhaustion.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BatchOrchestrationService {

    private final JobLauncher asyncJobLauncher;
    private final Job fileProcessingJob;
    private final BatchJobConfig batchJobConfig;
    private final FileSplitterService fileSplitterService;
    private final FileParsingStrategyResolver strategyResolver;
    private final FileProcessingMetadataRepository metadataRepository;
    private final BatchProperties batchProperties;

    @Qualifier("batchTaskExecutor")
    private final TaskExecutor taskExecutor;

    /**
     * Processes a list of files concurrently, respecting maxConcurrentJobs.
     */
    public void processFiles(List<File> files) {
        if (files.isEmpty()) {
            log.info("No files to process.");
            return;
        }

        Semaphore semaphore = new Semaphore(batchProperties.getMaxConcurrentJobs());
        List<Future<?>> futures = new ArrayList<>();
        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor(); // Java 21 virtual threads

        for (File file : files) {
            try {
                semaphore.acquire();
                Future<?> future = executor.submit(() -> {
                    try {
                        processFile(file);
                    } finally {
                        semaphore.release();
                    }
                });
                futures.add(future);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.error("Interrupted while waiting for semaphore", e);
            }
        }

        // Wait for all to complete
        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (ExecutionException e) {
                log.error("File processing task failed: {}", e.getCause().getMessage(), e);
            }
        }

        executor.shutdown();
        log.info("All {} files processed.", files.size());
    }

    /**
     * Processes a single file by calculating chunks and launching a batch job.
     */
    private void processFile(File file) {
        log.info("Processing file: {}", file.getName());

        try {
            FileParsingStrategy strategy = strategyResolver.resolve(file);
            long totalRecords = strategy.countRecords(file);
            List<FileChunk> chunks = fileSplitterService.calculateChunks(file, totalRecords);

            updateMetadata(file.getName(), totalRecords);

            // Process all chunks concurrently using the task executor
            List<CompletableFuture<Void>> chunkFutures = new ArrayList<>();
            AtomicInteger processedCount = new AtomicInteger(0);

            for (FileChunk chunk : chunks) {
                CompletableFuture<Void> chunkFuture = CompletableFuture.runAsync(() -> {
                    try {
                        processChunk(chunk, file);
                        processedCount.addAndGet(chunk.maxLines());
                    } catch (Exception e) {
                        log.error("Chunk processing failed: {} - {}", chunk.chunkId(), e.getMessage(), e);
                    }
                }, taskExecutor);
                chunkFutures.add(chunkFuture);
            }

            // Wait for all chunks to complete
            CompletableFuture.allOf(chunkFutures.toArray(new CompletableFuture[0])).join();

            updateMetadataProcessedCount(file.getName(), processedCount.get());
            log.info("Completed processing file: {} ({} records)", file.getName(), totalRecords);

        } catch (Exception e) {
            log.error("Failed to process file: {}", file.getName(), e);
            updateMetadataFailed(file.getName(), e.getMessage());
        }
    }

    private void processChunk(FileChunk chunk, File file) throws Exception {
        // Each chunk runs as a separate Spring Batch Step for transactional isolation
        Step step = batchJobConfig.createChunkStep(
                "step_" + chunk.chunkId(), chunk, taskExecutor);

        JobParameters params = new JobParametersBuilder()
                .addString("fileName", file.getName())
                .addString("filePath", file.getAbsolutePath())
                .addLong("chunkIndex", (long) chunk.chunkIndex())
                .addLong("startLine", chunk.startLine())
                .addString("runTimestamp", LocalDateTime.now().toString())
                .toJobParameters();

        log.debug("Launching job for chunk: {}", chunk.chunkId());
        asyncJobLauncher.run(fileProcessingJob, params);
    }

    private void updateMetadata(String fileName, long totalRecords) {
        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setTotalRecords(totalRecords);
            meta.setStatus(FileProcessingMetadata.ProcessingStatus.IN_PROGRESS);
            metadataRepository.save(meta);
        });
    }

    private void updateMetadataProcessedCount(String fileName, long count) {
        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setProcessedRecords(count);
            metadataRepository.save(meta);
        });
    }

    private void updateMetadataFailed(String fileName, String errorMsg) {
        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setStatus(FileProcessingMetadata.ProcessingStatus.FAILED);
            meta.setErrorMessage(errorMsg);
            metadataRepository.save(meta);
        });
    }
}
