package com.logprocessor.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * Configures thread pools for concurrent file processing.
 * Uses Virtual Threads (Java 21) for I/O-bound operations.
 */
@Configuration
@RequiredArgsConstructor
public class ThreadPoolConfig {

    private final BatchProperties batchProperties;

    /**
     * Task executor for Spring Batch parallel steps.
     */
    @Bean("batchTaskExecutor")
    public TaskExecutor batchTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(batchProperties.getThreadPoolSize());
        executor.setMaxPoolSize(batchProperties.getThreadPoolSize() * 2);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("batch-worker-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(60);
        executor.initialize();
        return executor;
    }

    /**
     * Task executor for file scanning and movement (uses virtual threads for I/O).
     */
    @Bean("fileTaskExecutor")
    public TaskExecutor fileTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(4);
        executor.setThreadNamePrefix("file-io-");
        executor.initialize();
        return executor;
    }
}
