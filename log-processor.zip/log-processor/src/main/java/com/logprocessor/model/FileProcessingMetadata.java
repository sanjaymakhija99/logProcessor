package com.logprocessor.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Tracks metadata and processing status for each file.
 */
@Entity
@Table(name = "file_processing_metadata", indexes = {
        @Index(name = "idx_file_name", columnList = "fileName"),
        @Index(name = "idx_status", columnList = "status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileProcessingMetadata {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 512)
    private String fileName;

    @Column(nullable = false, length = 512)
    private String sourcePath;

    @Column(length = 512)
    private String processedPath;

    @Column(nullable = false)
    private Long fileSizeBytes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ProcessingStatus status;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private LogRecord.FileType fileType;

    private Long totalRecords;
    private Long processedRecords;
    private Long failedRecords;

    @Column(columnDefinition = "TEXT")
    private String errorMessage;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum ProcessingStatus {
        PENDING, IN_PROGRESS, COMPLETED, FAILED, MOVED
    }
}
