package com.logprocessor.service;

import com.logprocessor.config.FileProperties;
import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.model.LogRecord;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Scans the Windows source folder and registers new files for processing.
 *
 * Paths are resolved via {@link FileProperties#getSourcePath()} which
 * returns a normalised {@link Path} regardless of whether the configured
 * value uses backslashes, forward-slashes, or a mix.
 *
 * Example accepted configurations:
 *   app.file.source-folder: D:\LogFiles\source
 *   app.file.source-folder: D:/LogFiles/source
 *   SOURCE_FOLDER=D:\LogFiles\source   (environment variable)
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileScannerService {

    private final FileProperties fileProperties;
    private final FileProcessingMetadataRepository metadataRepository;
    private final FileParsingStrategyResolver strategyResolver;

    /**
     * Scans the source folder and returns files that are pending processing.
     * Already-processed files (COMPLETED or MOVED) are silently skipped.
     */
    @Transactional
    public List<File> scanAndRegisterFiles() {
        Path sourcePath = fileProperties.getSourcePath();
        File sourceDir  = sourcePath.toFile();

        ensureFolderExists(sourcePath);

        File[] files = sourceDir.listFiles(file ->
                file.isFile() && isSupportedExtension(file));

        if (files == null || files.length == 0) {
            log.info("No supported files found in: {}", sourcePath);
            return List.of();
        }

        List<File> pendingFiles = Arrays.stream(files)
                .filter(this::isNotAlreadyProcessed)
                .peek(this::registerFile)
                .toList();

        log.info("Scan complete — {} pending file(s) in: {}", pendingFiles.size(), sourcePath);
        return pendingFiles;
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    private boolean isSupportedExtension(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        return fileProperties.getSupportedExtensions().contains(ext)
                && strategyResolver.isSupported(file);
    }

    private boolean isNotAlreadyProcessed(File file) {
        return !metadataRepository.existsByFileNameAndStatus(
                    file.getName(), FileProcessingMetadata.ProcessingStatus.COMPLETED)
            && !metadataRepository.existsByFileNameAndStatus(
                    file.getName(), FileProcessingMetadata.ProcessingStatus.MOVED);
    }

    private void registerFile(File file) {
        Optional<FileProcessingMetadata> existing =
                metadataRepository.findByFileName(file.getName());

        if (existing.isPresent()) {
            log.debug("Already registered — skipping: {}", file.getName());
            return;
        }

        FileProcessingMetadata metadata = FileProcessingMetadata.builder()
                .fileName(file.getName())
                .sourcePath(file.getAbsolutePath())   // stores the OS-canonical absolute path
                .fileSizeBytes(file.length())
                .status(FileProcessingMetadata.ProcessingStatus.PENDING)
                .fileType(resolveFileType(file))
                .build();

        metadataRepository.save(metadata);
        log.info("Registered: {} ({} bytes) from {}",
                file.getName(), file.length(), file.getAbsolutePath());
    }

    private LogRecord.FileType resolveFileType(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        return switch (ext) {
            case "csv"          -> LogRecord.FileType.CSV;
            case "xlsx", "xls"  -> LogRecord.FileType.EXCEL;
            default             -> LogRecord.FileType.TXT;
        };
    }

    /**
     * Creates the folder hierarchy if it does not yet exist.
     * On Windows this will create D:\LogFiles\source including any
     * intermediate directories that are missing.
     */
    private void ensureFolderExists(Path folder) {
        if (!folder.toFile().exists()) {
            try {
                Files.createDirectories(folder);
                log.info("Created source directory: {}", folder);
            } catch (IOException e) {
                log.error("Cannot create source directory '{}': {}", folder, e.getMessage(), e);
                throw new IllegalStateException(
                        "Source folder does not exist and could not be created: " + folder, e);
            }
        }
    }
}
