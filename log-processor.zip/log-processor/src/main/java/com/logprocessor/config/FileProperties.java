package com.logprocessor.config;

import com.logprocessor.util.WindowsPathUtils;
import jakarta.annotation.PostConstruct;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import java.nio.file.Path;
import java.util.List;

/**
 * Typed configuration properties for file processing.
 *
 * All three folder paths are treated as Windows-compatible paths and
 * normalised at startup via {@link WindowsPathUtils}.  This means:
 *
 *   SOURCE_FOLDER=D:\LogFiles\source    ← env var / YAML value
 *   SOURCE_FOLDER=D:/LogFiles/source    ← both accepted
 *
 * Use {@link #getSourcePath()}, {@link #getProcessedPath()},
 * and {@link #getErrorPath()} (return {@link Path}) in code rather
 * than the raw string getters, to ensure OS-correct path handling.
 */
@Component
@ConfigurationProperties(prefix = "app.file")
@Validated
@Getter
@Setter
@Slf4j
public class FileProperties {

    @NotBlank
    private String sourceFolder;

    @NotBlank
    private String processedFolder;

    @NotBlank
    private String errorFolder;

    @Min(1)
    private int chunkSize = 1000;

    private long splitThresholdBytes = 100 * 1024 * 1024; // 100 MB

    @Min(1000)
    private int maxLinesPerSplit = 50000;

    @NotEmpty
    private List<String> supportedExtensions;

    // -----------------------------------------------------------------------
    // Normalised Path accessors (use these in all service code)
    // -----------------------------------------------------------------------

    /** Returns the normalised source folder as a {@link Path}. */
    public Path getSourcePath() {
        return WindowsPathUtils.normalize(sourceFolder);
    }

    /** Returns the normalised processed folder as a {@link Path}. */
    public Path getProcessedPath() {
        return WindowsPathUtils.normalize(processedFolder);
    }

    /** Returns the normalised error folder as a {@link Path}. */
    public Path getErrorPath() {
        return WindowsPathUtils.normalize(errorFolder);
    }

    // -----------------------------------------------------------------------
    // Startup validation
    // -----------------------------------------------------------------------

    /**
     * Validates and logs all configured paths after properties are bound.
     * Fails fast at startup if any path string is syntactically invalid.
     */
    @PostConstruct
    public void validateAndLogPaths() {
        WindowsPathUtils.validate(sourceFolder,    "app.file.source-folder");
        WindowsPathUtils.validate(processedFolder, "app.file.processed-folder");
        WindowsPathUtils.validate(errorFolder,     "app.file.error-folder");

        log.info("=== File Path Configuration ===");
        log.info("  Source    : {}", getSourcePath());
        log.info("  Processed : {}", getProcessedPath());
        log.info("  Error     : {}", getErrorPath());

        if (WindowsPathUtils.isWindowsAbsolutePath(sourceFolder)) {
            log.info("  [Windows absolute path detected — using D: drive]");
        }
    }
}
