package com.logprocessor.strategy;

import com.logprocessor.model.LogRecord;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.List;

/**
 * Resolves the correct FileParsingStrategy for a given file.
 * Follows the Strategy + Factory pattern.
 */
@Component
@RequiredArgsConstructor
public class FileParsingStrategyResolver {

    private final List<FileParsingStrategy> strategies;

    /**
     * Returns the strategy that supports the given file.
     *
     * @throws IllegalArgumentException if no strategy supports the file
     */
    public FileParsingStrategy resolve(File file) {
        return strategies.stream()
                .filter(s -> s.supports(file))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "No parsing strategy found for file: " + file.getName()));
    }

    public boolean isSupported(File file) {
        return strategies.stream().anyMatch(s -> s.supports(file));
    }
}
