package com.logprocessor;

import com.logprocessor.util.WindowsPathUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.nio.file.Path;

import static org.assertj.core.api.Assertions.*;

class WindowsPathUtilsTest {

    // -----------------------------------------------------------------------
    // normalize() — happy paths
    // -----------------------------------------------------------------------

    @Test
    void shouldNormalizeWindowsBackslashPath() {
        Path path = WindowsPathUtils.normalize("D:\\LogFiles\\source");
        assertThat(path).isNotNull();
        assertThat(path.toString()).doesNotContain("\\\\"); // no double-backslash
    }

    @Test
    void shouldNormalizeWindowsForwardSlashPath() {
        Path path = WindowsPathUtils.normalize("D:/LogFiles/source");
        assertThat(path).isNotNull();
        // Both formats produce the same logical path
        Path backslash = WindowsPathUtils.normalize("D:\\LogFiles\\source");
        assertThat(path.toString()).isEqualToIgnoringCase(backslash.toString());
    }

    @Test
    void shouldStripTrailingSeparator() {
        Path withSlash    = WindowsPathUtils.normalize("D:/LogFiles/source/");
        Path withoutSlash = WindowsPathUtils.normalize("D:/LogFiles/source");
        assertThat(withSlash.toString()).isEqualToIgnoringCase(withoutSlash.toString());
    }

    @Test
    void shouldStripSurroundingDoubleQuotes() {
        Path quoted   = WindowsPathUtils.normalize("\"D:/LogFiles/source\"");
        Path unquoted = WindowsPathUtils.normalize("D:/LogFiles/source");
        assertThat(quoted.toString()).isEqualToIgnoringCase(unquoted.toString());
    }

    @Test
    void shouldStripSurroundingSingleQuotes() {
        Path quoted   = WindowsPathUtils.normalize("'D:/LogFiles/source'");
        Path unquoted = WindowsPathUtils.normalize("D:/LogFiles/source");
        assertThat(quoted.toString()).isEqualToIgnoringCase(unquoted.toString());
    }

    @Test
    void shouldHandleRelativePath() {
        // Relative paths (./data/logs/source) must also normalise correctly
        Path path = WindowsPathUtils.normalize("./data/logs/source");
        assertThat(path).isNotNull();
    }

    // -----------------------------------------------------------------------
    // normalize() — edge cases and error cases
    // -----------------------------------------------------------------------

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "\t"})
    void shouldThrowForBlankPath(String blank) {
        assertThatThrownBy(() -> WindowsPathUtils.normalize(blank))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("must not be blank");
    }

    @Test
    void shouldThrowForNullPath() {
        assertThatThrownBy(() -> WindowsPathUtils.normalize(null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // -----------------------------------------------------------------------
    // isWindowsAbsolutePath()
    // -----------------------------------------------------------------------

    @ParameterizedTest
    @ValueSource(strings = {
            "D:\\LogFiles\\source",
            "D:/LogFiles/source",
            "C:\\Windows\\Temp",
            "E:/data"
    })
    void shouldDetectWindowsAbsolutePaths(String path) {
        assertThat(WindowsPathUtils.isWindowsAbsolutePath(path)).isTrue();
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "./data/logs",
            "/var/logs",
            "relative/path",
            ""
    })
    void shouldNotDetectNonWindowsPaths(String path) {
        assertThat(WindowsPathUtils.isWindowsAbsolutePath(path)).isFalse();
    }

    // -----------------------------------------------------------------------
    // validate()
    // -----------------------------------------------------------------------

    @Test
    void shouldPassValidationForValidPath() {
        assertThatNoException()
                .isThrownBy(() -> WindowsPathUtils.validate("D:/LogFiles/source", "source-folder"));
    }

    @Test
    void shouldFailValidationForBlankPath() {
        assertThatThrownBy(() -> WindowsPathUtils.validate("", "source-folder"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("source-folder");
    }

    // -----------------------------------------------------------------------
    // toFile()
    // -----------------------------------------------------------------------

    @Test
    void shouldReturnFileForValidPath() {
        var file = WindowsPathUtils.toFile("D:/LogFiles/source");
        assertThat(file).isNotNull();
        assertThat(file.getPath()).isNotBlank();
    }

    // -----------------------------------------------------------------------
    // toDisplayString()
    // -----------------------------------------------------------------------

    @Test
    void shouldReturnNonBlankDisplayString() {
        String display = WindowsPathUtils.toDisplayString("D:/LogFiles/source");
        assertThat(display).isNotBlank();
    }
}
