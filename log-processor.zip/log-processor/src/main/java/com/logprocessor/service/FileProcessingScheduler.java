package com.logprocessor.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Polls the source folder on a configurable schedule.
 * Uses an AtomicBoolean to prevent overlapping executions.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class FileProcessingScheduler {

    private final FileScannerService fileScannerService;
    private final BatchOrchestrationService orchestrationService;

    private final AtomicBoolean running = new AtomicBoolean(false);

    /**
     * Runs every 60 seconds by default.
     * Configurable via: app.scheduler.cron (override in application.yml)
     */
    @Scheduled(fixedDelayString = "${app.scheduler.fixed-delay-ms:60000}",
               initialDelayString = "${app.scheduler.initial-delay-ms:5000}")
    public void triggerProcessing() {
        if (!running.compareAndSet(false, true)) {
            log.warn("Previous processing run still active. Skipping this trigger.");
            return;
        }

        try {
            log.info("Scheduler triggered: scanning for files to process...");
            List<File> files = fileScannerService.scanAndRegisterFiles();

            if (!files.isEmpty()) {
                orchestrationService.processFiles(files);
            }
        } catch (Exception e) {
            log.error("Error during scheduled file processing: {}", e.getMessage(), e);
        } finally {
            running.set(false);
        }
    }
}
