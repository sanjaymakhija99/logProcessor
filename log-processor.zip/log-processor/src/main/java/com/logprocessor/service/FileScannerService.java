package com.logprocessor.service;

import com.logprocessor.config.FileProperties;
import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.model.LogRecord;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Scans the source folder and registers files for processing.
 * Uses the repository to track which files have already been processed
 * to support idempotent restarts.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileScannerService {

    private final FileProperties fileProperties;
    private final FileProcessingMetadataRepository metadataRepository;
    private final FileParsingStrategyResolver strategyResolver;

    /**
     * Scans the source folder and returns files that are pending processing.
     */
    @Transactional
    public List<File> scanAndRegisterFiles() {
        File sourceDir = Paths.get(fileProperties.getSourceFolder()).toFile();
        ensureFolderExists(sourceDir);

        File[] files = sourceDir.listFiles(file ->
                file.isFile() && isSupportedExtension(file));

        if (files == null || files.length == 0) {
            log.info("No files found in source folder: {}", fileProperties.getSourceFolder());
            return List.of();
        }

        List<File> pendingFiles = Arrays.stream(files)
                .filter(this::isNotAlreadyProcessed)
                .peek(this::registerFile)
                .toList();

        log.info("Found {} pending files to process", pendingFiles.size());
        return pendingFiles;
    }

    private boolean isSupportedExtension(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        return fileProperties.getSupportedExtensions().contains(ext)
                && strategyResolver.isSupported(file);
    }

    private boolean isNotAlreadyProcessed(File file) {
        return !metadataRepository.existsByFileNameAndStatus(
                file.getName(), FileProcessingMetadata.ProcessingStatus.COMPLETED)
            && !metadataRepository.existsByFileNameAndStatus(
                file.getName(), FileProcessingMetadata.ProcessingStatus.MOVED);
    }

    private void registerFile(File file) {
        Optional<FileProcessingMetadata> existing = metadataRepository.findByFileName(file.getName());
        if (existing.isPresent()) {
            log.debug("File already registered: {}", file.getName());
            return;
        }

        LogRecord.FileType fileType = resolveFileType(file);
        FileProcessingMetadata metadata = FileProcessingMetadata.builder()
                .fileName(file.getName())
                .sourcePath(file.getAbsolutePath())
                .fileSizeBytes(file.length())
                .status(FileProcessingMetadata.ProcessingStatus.PENDING)
                .fileType(fileType)
                .build();

        metadataRepository.save(metadata);
        log.info("Registered file for processing: {} ({} bytes)", file.getName(), file.length());
    }

    private LogRecord.FileType resolveFileType(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        return switch (ext) {
            case "csv"          -> LogRecord.FileType.CSV;
            case "xlsx", "xls"  -> LogRecord.FileType.EXCEL;
            default             -> LogRecord.FileType.TXT;
        };
    }

    private void ensureFolderExists(File folder) {
        if (!folder.exists()) {
            boolean created = folder.mkdirs();
            log.info("Created source folder: {} ({})", folder.getPath(), created ? "success" : "already exists");
        }
    }
}
