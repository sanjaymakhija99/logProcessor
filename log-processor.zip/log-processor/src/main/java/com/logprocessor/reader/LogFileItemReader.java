package com.logprocessor.reader;

import com.logprocessor.model.LogRecord;
import com.logprocessor.service.FileSplitterService.FileChunk;
import com.logprocessor.strategy.FileParsingStrategy;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import java.util.Iterator;
import java.util.List;

/**
 * Spring Batch ItemReader that reads LogRecord objects from a file chunk.
 * Thread-safe via synchronized iterator access.
 */
@Slf4j
public class LogFileItemReader implements ItemReader<LogRecord> {

    private final FileChunk chunk;
    private final FileParsingStrategyResolver strategyResolver;

    private Iterator<LogRecord> recordIterator;
    private boolean initialized = false;

    public LogFileItemReader(FileChunk chunk, FileParsingStrategyResolver strategyResolver) {
        this.chunk = chunk;
        this.strategyResolver = strategyResolver;
    }

    @Override
    public synchronized LogRecord read()
            throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

        if (!initialized) {
            initialize();
        }

        if (recordIterator != null && recordIterator.hasNext()) {
            return recordIterator.next();
        }
        return null; // signals end of data to Spring Batch
    }

    private void initialize() {
        try {
            FileParsingStrategy strategy = strategyResolver.resolve(chunk.file());
            log.debug("Reading chunk {} using strategy: {}",
                    chunk.chunkId(), strategy.getClass().getSimpleName());

            List<LogRecord> records = strategy.parse(chunk.file(), chunk.startLine(), chunk.maxLines());
            recordIterator = records.iterator();
            initialized = true;

            log.debug("Loaded {} records from chunk {}", records.size(), chunk.chunkId());
        } catch (Exception e) {
            log.error("Failed to initialize reader for chunk {}: {}", chunk.chunkId(), e.getMessage(), e);
            throw new RuntimeException("Failed to read chunk: " + chunk.chunkId(), e);
        }
    }
}
