-- =============================================================================
-- schema.sql
-- Executed automatically at every startup via spring.sql.init.mode=always
-- Uses IF NOT EXISTS guards so re-runs are safe (idempotent).
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Sequence for LogRecord primary-key (allocationSize=500 in JPA entity)
-- H2 supports standard CREATE SEQUENCE syntax.
-- -----------------------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS log_record_seq
    START WITH 1
    INCREMENT BY 500
    NOCACHE;

-- -----------------------------------------------------------------------------
-- TABLE: log_records
-- Stores every parsed line from every processed log file.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS log_records (
    id           BIGINT        NOT NULL DEFAULT NEXT VALUE FOR log_record_seq,
    source_file  VARCHAR(512)  NOT NULL,
    line_number  BIGINT        NOT NULL,
    log_level    VARCHAR(50),
    timestamp    VARCHAR(100),
    component    VARCHAR(200),
    message      CLOB,
    raw_content  CLOB,
    file_type    VARCHAR(20)   NOT NULL,
    created_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_log_records PRIMARY KEY (id),
    CONSTRAINT chk_log_records_file_type
        CHECK (file_type IN ('CSV', 'EXCEL', 'TXT'))
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_log_records_source_file ON log_records (source_file);
CREATE INDEX IF NOT EXISTS idx_log_records_log_level   ON log_records (log_level);
CREATE INDEX IF NOT EXISTS idx_log_records_created_at  ON log_records (created_at);

-- -----------------------------------------------------------------------------
-- TABLE: file_processing_metadata
-- Tracks per-file processing lifecycle (PENDING → IN_PROGRESS → COMPLETED/FAILED → MOVED).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS file_processing_metadata (
    id                BIGINT        NOT NULL AUTO_INCREMENT,
    file_name         VARCHAR(512)  NOT NULL,
    source_path       VARCHAR(512)  NOT NULL,
    processed_path    VARCHAR(512),
    file_size_bytes   BIGINT        NOT NULL,
    status            VARCHAR(20)   NOT NULL DEFAULT 'PENDING',
    file_type         VARCHAR(20)   NOT NULL,
    total_records     BIGINT,
    processed_records BIGINT,
    failed_records    BIGINT,
    error_message     CLOB,
    created_at        TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT pk_file_processing_metadata   PRIMARY KEY (id),
    CONSTRAINT uq_file_processing_file_name  UNIQUE (file_name),
    CONSTRAINT chk_file_metadata_status
        CHECK (status IN ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'MOVED')),
    CONSTRAINT chk_file_metadata_file_type
        CHECK (file_type IN ('CSV', 'EXCEL', 'TXT'))
);

-- Indexes for status-based lookups and file-name lookups
CREATE INDEX IF NOT EXISTS idx_file_metadata_file_name ON file_processing_metadata (file_name);
CREATE INDEX IF NOT EXISTS idx_file_metadata_status    ON file_processing_metadata (status);
CREATE INDEX IF NOT EXISTS idx_file_metadata_created   ON file_processing_metadata (created_at);
