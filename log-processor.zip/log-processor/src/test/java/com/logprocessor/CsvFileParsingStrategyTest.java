package com.logprocessor;

import com.logprocessor.model.LogRecord;
import com.logprocessor.strategy.CsvFileParsingStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.*;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class CsvFileParsingStrategyTest {

    private CsvFileParsingStrategy strategy;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        strategy = new CsvFileParsingStrategy();
    }

    @Test
    void shouldSupportCsvFiles() {
        File csvFile = new File("test.csv");
        assertThat(strategy.supports(csvFile)).isTrue();
    }

    @Test
    void shouldNotSupportTxtFiles() {
        File txtFile = new File("test.txt");
        assertThat(strategy.supports(txtFile)).isFalse();
    }

    @Test
    void shouldParseCsvFileWithHeaders() throws IOException {
        File csv = tempDir.resolve("test.csv").toFile();
        try (PrintWriter writer = new PrintWriter(csv)) {
            writer.println("timestamp,level,component,message");
            writer.println("2024-01-15 10:00:00,INFO,MyService,Application started");
            writer.println("2024-01-15 10:00:01,ERROR,MyService,Something went wrong");
        }

        List<LogRecord> records = strategy.parse(csv, 0, -1);

        assertThat(records).hasSize(2);
        assertThat(records.get(0).getLogLevel()).isEqualTo("INFO");
        assertThat(records.get(0).getComponent()).isEqualTo("MyService");
        assertThat(records.get(1).getLogLevel()).isEqualTo("ERROR");
    }

    @Test
    void shouldRespectStartLineAndMaxLines() throws IOException {
        File csv = tempDir.resolve("big.csv").toFile();
        try (PrintWriter writer = new PrintWriter(csv)) {
            writer.println("timestamp,level,component,message");
            for (int i = 0; i < 100; i++) {
                writer.println("2024-01-15 10:00:00,INFO,Svc,Message " + i);
            }
        }

        List<LogRecord> records = strategy.parse(csv, 10, 20);
        assertThat(records).hasSize(20);
    }

    @Test
    void shouldCountRecordsExcludingHeader() throws IOException {
        File csv = tempDir.resolve("count.csv").toFile();
        try (PrintWriter writer = new PrintWriter(csv)) {
            writer.println("timestamp,level,component,message");
            writer.println("2024-01-15,INFO,Svc,Msg1");
            writer.println("2024-01-15,WARN,Svc,Msg2");
        }

        assertThat(strategy.countRecords(csv)).isEqualTo(2);
    }

    @Test
    void shouldHandleEmptyFile() throws IOException {
        File csv = tempDir.resolve("empty.csv").toFile();
        csv.createNewFile();

        List<LogRecord> records = strategy.parse(csv, 0, -1);
        assertThat(records).isEmpty();
    }
}
