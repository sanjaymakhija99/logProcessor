package com.logprocessor.strategy;

import com.logprocessor.model.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses plain TXT log files.
 * Supports common log formats like: 2024-01-15 10:30:00 ERROR [MyClass] - Some message
 */
@Component
@Slf4j
public class TxtFileParsingStrategy implements FileParsingStrategy {

    // Pattern: YYYY-MM-DD HH:MM:SS LEVEL [component] - message
    private static final Pattern LOG_PATTERN = Pattern.compile(
            "^(\\d{4}-\\d{2}-\\d{2}[T ]\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?)\\s+" +
            "(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL|SEVERE)?\\s*" +
            "(?:\\[([^\\]]+)\\])?\\s*[-:]?\\s*(.*)$",
            Pattern.CASE_INSENSITIVE
    );

    @Override
    public boolean supports(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        return "txt".equals(ext) || "log".equals(ext);
    }

    @Override
    public List<LogRecord> parse(File file, long startLine, int maxLines) {
        List<LogRecord> records = new ArrayList<>();
        long currentLine = 0;
        long linesRead = 0;

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8), 65536)) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (currentLine < startLine) {
                    currentLine++;
                    continue;
                }
                if (maxLines > 0 && linesRead >= maxLines) break;

                LogRecord record = parseTxtLine(line, file.getName(), currentLine + 1);
                if (record != null) {
                    records.add(record);
                    linesRead++;
                }
                currentLine++;
            }

        } catch (IOException e) {
            log.error("Error parsing TXT file: {}", file.getName(), e);
        }

        return records;
    }

    @Override
    public long countRecords(File file) {
        long count = 0;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8), 65536)) {
            while (reader.readLine() != null) count++;
        } catch (IOException e) {
            log.error("Error counting lines in TXT: {}", file.getName(), e);
        }
        return count;
    }

    @Override
    public LogRecord.FileType getFileType() {
        return LogRecord.FileType.TXT;
    }

    private LogRecord parseTxtLine(String line, String fileName, long lineNumber) {
        if (line == null || line.isBlank()) return null;

        Matcher matcher = LOG_PATTERN.matcher(line.trim());
        if (matcher.matches()) {
            return LogRecord.builder()
                    .sourceFile(fileName)
                    .lineNumber(lineNumber)
                    .timestamp(matcher.group(1))
                    .logLevel(matcher.group(2))
                    .component(matcher.group(3))
                    .message(matcher.group(4))
                    .rawContent(line)
                    .fileType(LogRecord.FileType.TXT)
                    .build();
        }

        // No pattern match: store as raw content
        return LogRecord.builder()
                .sourceFile(fileName)
                .lineNumber(lineNumber)
                .rawContent(line)
                .fileType(LogRecord.FileType.TXT)
                .build();
    }
}
