package com.logprocessor.config;

import com.logprocessor.batch.FileProcessingJobListener;
import com.logprocessor.batch.LogRecordSkipListener;
import com.logprocessor.model.LogRecord;
import com.logprocessor.processor.LogRecordItemProcessor;
import com.logprocessor.reader.LogFileItemReader;
import com.logprocessor.service.FileSplitterService.FileChunk;
import com.logprocessor.strategy.FileParsingStrategyResolver;
import com.logprocessor.writer.LogRecordItemWriter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Configures the Spring Batch job and steps.
 *
 * Job flow:
 *   1. scanStep           — lightweight tasklet that logs the incoming file
 *   2. defaultProcessingStep — no-op template; real per-chunk steps are
 *                             created at runtime via createChunkStep()
 *   3. File movement      — handled by FileProcessingJobListener after job ends
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class BatchJobConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final FileProperties fileProperties;
    private final FileProcessingJobListener jobListener;
    private final LogRecordSkipListener skipListener;
    private final LogRecordItemProcessor itemProcessor;
    private final LogRecordItemWriter itemWriter;
    private final FileParsingStrategyResolver strategyResolver;

    // -----------------------------------------------------------------------
    // Job
    // -----------------------------------------------------------------------

    @Bean("fileProcessingJob")
    public Job fileProcessingJob(@Qualifier("batchTaskExecutor") TaskExecutor taskExecutor) {
        return new JobBuilder("fileProcessingJob", jobRepository)
                .listener(jobListener)
                .start(scanStep())
                .next(defaultProcessingStep(taskExecutor))
                .build();
    }

    // -----------------------------------------------------------------------
    // Steps
    // -----------------------------------------------------------------------

    /** Logs the file name; used as the first step in every job execution. */
    @Bean
    public Step scanStep() {
        Tasklet scanTasklet = (contribution, chunkContext) -> {
            Object fileNameParam = chunkContext.getStepContext().getJobParameters().get("fileName");
            log.info("Scan step: preparing to process file '{}'", fileNameParam);
            return RepeatStatus.FINISHED;
        };

        return new StepBuilder("scanStep", jobRepository)
                .tasklet(scanTasklet, transactionManager)
                .build();
    }

    /**
     * No-op default processing step — serves as the job template.
     * Actual file processing is done by steps built via createChunkStep().
     */
    @Bean
    public Step defaultProcessingStep(@Qualifier("batchTaskExecutor") TaskExecutor taskExecutor) {
        return new StepBuilder("defaultProcessingStep", jobRepository)
                .<LogRecord, LogRecord>chunk(fileProperties.getChunkSize(), transactionManager)
                .reader(() -> null)
                .processor(itemProcessor)
                .writer(itemWriter)
                .faultTolerant()
                    .skipLimit(100)
                    .skip(Exception.class)
                    .retryLimit(3)
                    .retry(Exception.class)
                    .listener(skipListener)
                .taskExecutor(taskExecutor)
                .build();
    }

    /**
     * Runtime factory: creates one Step per FileChunk.
     * Called by BatchOrchestrationService for each logical file slice.
     *
     * @param stepName unique name, e.g. "step_events.csv_chunk_2"
     * @param chunk    the file slice to read
     * @param executor shared thread pool
     */
    public Step createChunkStep(String stepName, FileChunk chunk, TaskExecutor executor) {
        return new StepBuilder(stepName, jobRepository)
                .<LogRecord, LogRecord>chunk(fileProperties.getChunkSize(), transactionManager)
                .reader(new LogFileItemReader(chunk, strategyResolver))
                .processor(itemProcessor)
                .writer(itemWriter)
                .faultTolerant()
                    .skipLimit(100)
                    .skip(Exception.class)
                    .retryLimit(3)
                    .retry(Exception.class)
                    .listener(skipListener)
                .taskExecutor(executor)
                .build();
    }
}
