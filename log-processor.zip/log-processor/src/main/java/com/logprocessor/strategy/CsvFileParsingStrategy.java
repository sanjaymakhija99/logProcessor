package com.logprocessor.strategy;

import com.logprocessor.model.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Parses CSV log files.
 * Handles large files by reading line-by-line with skip/limit for chunking.
 */
@Component
@Slf4j
public class CsvFileParsingStrategy implements FileParsingStrategy {

    private static final String[] SUPPORTED_EXTENSIONS = {"csv"};

    @Override
    public boolean supports(File file) {
        String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
        for (String supported : SUPPORTED_EXTENSIONS) {
            if (supported.equals(ext)) return true;
        }
        return false;
    }

    @Override
    public List<LogRecord> parse(File file, long startLine, int maxLines) {
        List<LogRecord> records = new ArrayList<>();
        long currentLine = 0;
        long linesRead = 0;

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8), 65536)) {

            String headerLine = reader.readLine(); // skip header row
            String[] headers = headerLine != null ? headerLine.split(",", -1) : new String[0];

            String line;
            while ((line = reader.readLine()) != null) {
                if (currentLine < startLine) {
                    currentLine++;
                    continue;
                }
                if (maxLines > 0 && linesRead >= maxLines) break;

                LogRecord record = parseCsvLine(line, headers, file.getName(), currentLine + 2); // +2: 1-based + header
                if (record != null) {
                    records.add(record);
                    linesRead++;
                }
                currentLine++;
            }

        } catch (IOException e) {
            log.error("Error parsing CSV file: {}", file.getName(), e);
        }

        return records;
    }

    @Override
    public long countRecords(File file) {
        long count = 0;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8), 65536)) {
            reader.readLine(); // skip header
            while (reader.readLine() != null) count++;
        } catch (IOException e) {
            log.error("Error counting lines in CSV: {}", file.getName(), e);
        }
        return count;
    }

    @Override
    public LogRecord.FileType getFileType() {
        return LogRecord.FileType.CSV;
    }

    private LogRecord parseCsvLine(String line, String[] headers, String fileName, long lineNumber) {
        if (line == null || line.isBlank()) return null;

        String[] columns = line.split(",", -1);

        // Flexible parsing: try known column names, fallback to positional
        String timestamp = getColumn(columns, headers, "timestamp", 0);
        String logLevel  = getColumn(columns, headers, "level", 1);
        String component = getColumn(columns, headers, "component", 2);
        String message   = getColumn(columns, headers, "message", 3);

        return LogRecord.builder()
                .sourceFile(fileName)
                .lineNumber(lineNumber)
                .timestamp(timestamp)
                .logLevel(logLevel)
                .component(component)
                .message(message)
                .rawContent(line)
                .fileType(LogRecord.FileType.CSV)
                .build();
    }

    private String getColumn(String[] columns, String[] headers, String headerName, int fallbackIndex) {
        // Try to find by header name first
        for (int i = 0; i < headers.length; i++) {
            if (headers[i].trim().equalsIgnoreCase(headerName) && i < columns.length) {
                return columns[i].trim();
            }
        }
        // Fallback to positional
        return (fallbackIndex < columns.length) ? columns[fallbackIndex].trim() : "";
    }
}
