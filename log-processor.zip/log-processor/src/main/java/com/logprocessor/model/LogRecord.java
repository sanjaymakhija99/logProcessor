package com.logprocessor.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Entity representing a single parsed log record stored in the database.
 *
 * DDL is managed by schema.sql (spring.sql.init.mode=always).
 * Hibernate ddl-auto is set to 'none' — no auto table generation.
 */
@Entity
@Table(name = "log_records", indexes = {
        @Index(name = "idx_log_records_source_file", columnList = "source_file"),
        @Index(name = "idx_log_records_log_level",   columnList = "log_level"),
        @Index(name = "idx_log_records_created_at",  columnList = "created_at")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LogRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "log_record_seq")
    @SequenceGenerator(name = "log_record_seq", sequenceName = "log_record_seq", allocationSize = 500)
    private Long id;

    @Column(name = "source_file", nullable = false, length = 512)
    private String sourceFile;

    @Column(name = "line_number", nullable = false)
    private Long lineNumber;

    @Column(name = "log_level", length = 50)
    private String logLevel;

    @Column(name = "timestamp", length = 100)
    private String timestamp;

    @Column(name = "component", length = 200)
    private String component;

    @Lob
    @Column(name = "message")
    private String message;

    @Lob
    @Column(name = "raw_content")
    private String rawContent;

    @Enumerated(EnumType.STRING)
    @Column(name = "file_type", nullable = false, length = 20)
    private FileType fileType;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public enum FileType {
        CSV, EXCEL, TXT
    }
}
