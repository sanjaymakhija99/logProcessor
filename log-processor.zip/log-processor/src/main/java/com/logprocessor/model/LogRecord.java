package com.logprocessor.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Entity representing a single parsed log record stored in the database.
 */
@Entity
@Table(name = "log_records", indexes = {
        @Index(name = "idx_source_file", columnList = "sourceFile"),
        @Index(name = "idx_log_level", columnList = "logLevel"),
        @Index(name = "idx_created_at", columnList = "createdAt")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LogRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "log_record_seq")
    @SequenceGenerator(name = "log_record_seq", sequenceName = "log_record_seq", allocationSize = 500)
    private Long id;

    @Column(nullable = false, length = 512)
    private String sourceFile;

    @Column(nullable = false)
    private Long lineNumber;

    @Column(length = 50)
    private String logLevel;

    @Column(length = 100)
    private String timestamp;

    @Column(length = 200)
    private String component;

    @Column(columnDefinition = "TEXT")
    private String message;

    @Column(columnDefinition = "TEXT")
    private String rawContent;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private FileType fileType;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public enum FileType {
        CSV, EXCEL, TXT
    }
}
