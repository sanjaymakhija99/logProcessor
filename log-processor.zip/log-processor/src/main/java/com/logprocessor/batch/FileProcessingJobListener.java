package com.logprocessor.batch;

import com.logprocessor.model.FileProcessingMetadata;
import com.logprocessor.repository.FileProcessingMetadataRepository;
import com.logprocessor.service.FileMoverService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import java.io.File;

/**
 * Listens to job lifecycle events.
 * Moves files and updates metadata after job completion or failure.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class FileProcessingJobListener implements JobExecutionListener {

    private final FileMoverService fileMoverService;
    private final FileProcessingMetadataRepository metadataRepository;

    @Override
    public void beforeJob(@NonNull JobExecution jobExecution) {
        String fileName = jobExecution.getJobParameters().getString("fileName");
        String filePath = jobExecution.getJobParameters().getString("filePath");
        log.info("Starting job for file: {} | JobId: {}", fileName, jobExecution.getJobId());

        metadataRepository.findByFileName(fileName).ifPresent(meta -> {
            meta.setStatus(FileProcessingMetadata.ProcessingStatus.IN_PROGRESS);
            metadataRepository.save(meta);
        });
    }

    @Override
    public void afterJob(@NonNull JobExecution jobExecution) {
        String fileName = jobExecution.getJobParameters().getString("fileName");
        String filePath = jobExecution.getJobParameters().getString("filePath");
        File file = new File(filePath);

        if (jobExecution.getStatus().isUnsuccessful()) {
            log.error("Job FAILED for file: {} | Status: {}", fileName, jobExecution.getStatus());
            String error = jobExecution.getAllFailureExceptions().stream()
                    .map(Throwable::getMessage)
                    .reduce((a, b) -> a + "; " + b)
                    .orElse("Unknown error");

            metadataRepository.findByFileName(fileName).ifPresent(meta -> {
                meta.setStatus(FileProcessingMetadata.ProcessingStatus.FAILED);
                meta.setErrorMessage(error);
                metadataRepository.save(meta);
            });

            if (file.exists()) {
                fileMoverService.moveToError(file, error);
            }
        } else {
            log.info("Job COMPLETED for file: {} | Duration: {}ms",
                    fileName,
                    jobExecution.getEndTime() != null && jobExecution.getStartTime() != null
                            ? java.time.Duration.between(jobExecution.getStartTime(), jobExecution.getEndTime()).toMillis()
                            : -1);

            metadataRepository.findByFileName(fileName).ifPresent(meta -> {
                meta.setStatus(FileProcessingMetadata.ProcessingStatus.COMPLETED);
                metadataRepository.save(meta);
            });

            if (file.exists()) {
                fileMoverService.moveToProcessed(file);
            }
        }
    }
}
