package com.logprocessor.util;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Utility class for normalising and resolving Windows-style file paths.
 *
 * Handles all common path formats that come from a Windows D:\ environment:
 *
 *   D:\LogFiles\source          → standard Windows backslash
 *   D:/LogFiles/source          → forward-slash (common in YAML / env vars)
 *   D:\\LogFiles\\source        → double-escaped backslash (YAML literal)
 *   "D:\LogFiles\source"        → quoted path from env variable
 *   D:\LogFiles\source\         → trailing separator (normalised away)
 *
 * Java's java.nio.file.Paths.get() handles all these formats natively on
 * Windows JVMs.  On Linux/Mac (CI, Docker), forward-slash paths still work;
 * backslash paths are converted so tests and cross-platform runs succeed.
 */
@Slf4j
public final class WindowsPathUtils {

    private WindowsPathUtils() {
        // utility class — no instantiation
    }

    /**
     * Normalises a raw path string from config/environment and returns
     * a clean {@link Path} object that works on the current OS.
     *
     * <ul>
     *   <li>Strips surrounding quotes</li>
     *   <li>Replaces backslashes with the OS file separator</li>
     *   <li>Removes trailing separators</li>
     *   <li>Resolves any {@code .} or {@code ..} segments</li>
     * </ul>
     *
     * @param rawPath raw path from config, e.g. {@code D:\LogFiles\source}
     * @return normalised {@link Path}
     * @throws IllegalArgumentException if the path is blank or invalid
     */
    public static Path normalize(String rawPath) {
        if (rawPath == null || rawPath.isBlank()) {
            throw new IllegalArgumentException("File path must not be blank");
        }

        // 1. Strip surrounding quotes (e.g. SOURCE_FOLDER="D:\Logs")
        String cleaned = rawPath.trim();
        if ((cleaned.startsWith("\"") && cleaned.endsWith("\""))
                || (cleaned.startsWith("'") && cleaned.endsWith("'"))) {
            cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
        }

        // 2. Replace backslashes with the system separator so Paths.get()
        //    works correctly on every OS (no-op on Windows, fixes Linux CI).
        cleaned = cleaned.replace('\\', '/');

        // 3. Remove trailing separator
        while (cleaned.length() > 1 && cleaned.endsWith("/")) {
            cleaned = cleaned.substring(0, cleaned.length() - 1);
        }

        // 4. Re-apply OS-specific separator for final path construction
        //    On Windows: "/" is already accepted by Paths.get().
        //    On Linux: "/" is the native separator anyway.
        try {
            Path path = Paths.get(cleaned).normalize();
            log.debug("Normalised path: '{}' → '{}'", rawPath, path);
            return path;
        } catch (InvalidPathException e) {
            throw new IllegalArgumentException(
                    "Invalid file path: '" + rawPath + "' — " + e.getReason(), e);
        }
    }

    /**
     * Convenience method: normalises the path and returns a {@link File}.
     *
     * @param rawPath raw path string
     * @return {@link File} pointing to the normalised path
     */
    public static File toFile(String rawPath) {
        return normalize(rawPath).toFile();
    }

    /**
     * Returns a human-readable display string for the path,
     * using the OS-native separator (backslash on Windows, slash on Linux).
     *
     * @param rawPath raw path string
     * @return display-friendly path string
     */
    public static String toDisplayString(String rawPath) {
        return normalize(rawPath).toString();
    }

    /**
     * Validates that a configured path string is syntactically valid.
     * Does NOT check whether the path exists on disk.
     *
     * @param rawPath   path to validate
     * @param fieldName config field name, used in the error message
     * @throws IllegalArgumentException if the path is invalid
     */
    public static void validate(String rawPath, String fieldName) {
        try {
            normalize(rawPath);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "Configuration error — '" + fieldName + "': " + e.getMessage(), e);
        }
    }

    /**
     * Returns {@code true} if the path looks like a Windows absolute path,
     * e.g. {@code D:\...} or {@code D:/...}.
     */
    public static boolean isWindowsAbsolutePath(String rawPath) {
        if (rawPath == null || rawPath.length() < 3) return false;
        char drive = rawPath.charAt(0);
        char colon = rawPath.charAt(1);
        char sep   = rawPath.charAt(2);
        return Character.isLetter(drive)
                && colon == ':'
                && (sep == '\\' || sep == '/');
    }
}
