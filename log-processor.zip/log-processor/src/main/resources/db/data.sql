-- =============================================================================
-- data.sql
-- Seed / reference data executed at startup after schema.sql.
-- All inserts are guarded with MERGE (H2 upsert) so re-runs stay idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Seed: file_processing_metadata
-- Pre-register a set of "known" files so the dashboard / queries have
-- something to show right after a fresh boot.  Real files are registered
-- dynamically by FileScannerService; these rows are purely illustrative.
-- -----------------------------------------------------------------------------
MERGE INTO file_processing_metadata
    (file_name, source_path, file_size_bytes, status, file_type,
     total_records, processed_records, failed_records, created_at, updated_at)
KEY (file_name)
VALUES
    ('sample-app.log',
     './data/logs/source/sample-app.log',
     5120,
     'PENDING', 'TXT',
     NULL, NULL, NULL,
     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

    ('sample-events.csv',
     './data/logs/source/sample-events.csv',
     10240,
     'PENDING', 'CSV',
     NULL, NULL, NULL,
     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

    ('sample-report.xlsx',
     './data/logs/source/sample-report.xlsx',
     20480,
     'PENDING', 'EXCEL',
     NULL, NULL, NULL,
     CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- -----------------------------------------------------------------------------
-- Seed: log_records
-- A handful of representative records so H2 console queries return results
-- immediately without needing real files to be processed first.
-- -----------------------------------------------------------------------------
MERGE INTO log_records
    (id, source_file, line_number, log_level, timestamp, component,
     message, raw_content, file_type, created_at)
KEY (id)
VALUES
    (1,
     'sample-app.log', 1, 'INFO',
     '2024-01-15 08:00:00', 'ApplicationStartup',
     'Application started successfully',
     '2024-01-15 08:00:00 INFO [ApplicationStartup] - Application started successfully',
     'TXT', CURRENT_TIMESTAMP),

    (2,
     'sample-app.log', 2, 'DEBUG',
     '2024-01-15 08:00:01', 'DataSourceConfig',
     'H2 datasource initialised',
     '2024-01-15 08:00:01 DEBUG [DataSourceConfig] - H2 datasource initialised',
     'TXT', CURRENT_TIMESTAMP),

    (3,
     'sample-app.log', 3, 'WARN',
     '2024-01-15 08:01:00', 'FileScannerService',
     'Source folder does not exist yet; will be created on first scan',
     '2024-01-15 08:01:00 WARN [FileScannerService] - Source folder does not exist yet',
     'TXT', CURRENT_TIMESTAMP),

    (4,
     'sample-events.csv', 1, 'ERROR',
     '2024-01-15 09:00:00', 'PaymentService',
     'Transaction timeout after 30s',
     '2024-01-15 09:00:00,ERROR,PaymentService,Transaction timeout after 30s',
     'CSV', CURRENT_TIMESTAMP),

    (5,
     'sample-events.csv', 2, 'INFO',
     '2024-01-15 09:01:00', 'OrderService',
     'Order #12345 processed successfully',
     '2024-01-15 09:01:00,INFO,OrderService,Order #12345 processed successfully',
     'CSV', CURRENT_TIMESTAMP),

    (6,
     'sample-report.xlsx', 1, 'INFO',
     '2024-01-15 10:00:00', 'ReportGenerator',
     'Monthly report generation completed',
     '2024-01-15 10:00:00 INFO [ReportGenerator] Monthly report generation completed',
     'EXCEL', CURRENT_TIMESTAMP);
