package com.logprocessor.batch;

import com.logprocessor.model.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.SkipListener;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

/**
 * Logs skipped records and exceptions for observability.
 * Allows the batch job to continue despite individual record failures.
 */
@Component
@Slf4j
public class LogRecordSkipListener implements SkipListener<LogRecord, LogRecord> {

    @Override
    public void onSkipInRead(@NonNull Throwable t) {
        log.warn("Skipped record during READ phase: {}", t.getMessage());
    }

    @Override
    public void onSkipInProcess(LogRecord item, @NonNull Throwable t) {
        log.warn("Skipped record during PROCESS phase - file: {}, line: {}, error: {}",
                item.getSourceFile(), item.getLineNumber(), t.getMessage());
    }

    @Override
    public void onSkipInWrite(@NonNull LogRecord item, @NonNull Throwable t) {
        log.warn("Skipped record during WRITE phase - file: {}, line: {}, error: {}",
                item.getSourceFile(), item.getLineNumber(), t.getMessage());
    }
}
